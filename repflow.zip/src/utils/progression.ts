import { Workout, WorkoutExercise, ExerciseLog } from '../types';

/**
 * Generates smart weight progression suggestion based on historical data of an exercise.
 */
export function getProgressionSuggestion(
  exercise: WorkoutExercise,
  history: ExerciseLog[]
): { suggestedWeight: number; reason: string; action: 'increase' | 'maintain' | 'decrease' } {
  const defaultWeight = exercise.targetWeight || 10;

  // Filter logs for this specific exercise
  const exerciseLogs = history
    .filter((log) => log.exerciseId === exercise.exerciseId)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()); // newest first

  if (exerciseLogs.length === 0) {
    return {
      suggestedWeight: defaultWeight,
      reason: 'Primeira vez realizando este exercício! Comece com uma carga moderada.',
      action: 'maintain',
    };
  }

  // Get the most recent log
  const lastLog = exerciseLogs[0];
  
  // Parse target reps from repsRange (e.g., "6-8" -> min: 6, max: 8; "12" -> min: 12, max: 12)
  let targetMinReps = 8;
  let targetMaxReps = 12;
  const parts = exercise.repsRange.split('-');
  if (parts.length === 2) {
    targetMinReps = parseInt(parts[0], 10) || 8;
    targetMaxReps = parseInt(parts[1], 10) || 12;
  } else if (parts.length === 1) {
    targetMinReps = parseInt(parts[0], 10) || 8;
    targetMaxReps = targetMinReps;
  }

  const completedSets = lastLog.sets.filter((s) => s.completed);
  
  if (completedSets.length === 0) {
    return {
      suggestedWeight: defaultWeight,
      reason: 'Nenhuma série concluída no último treino. Mantenha a carga anterior para testar.',
      action: 'maintain',
    };
  }

  // Check how many sets achieved or exceeded the target MAX reps
  const allSetsSucceededMax = completedSets.every((s) => s.reps >= targetMaxReps);
  const allSetsSucceededMin = completedSets.every((s) => s.reps >= targetMinReps);
  
  // Check if we have multiple consecutive failing logs
  const consecutiveFailsCount = exerciseLogs.reduce((acc, currLog) => {
    const isFail = currLog.sets.filter(s => s.completed).some(s => s.reps < targetMinReps);
    if (isFail) return acc + 1;
    return acc;
  }, 0);

  // Take the weight of the last completed set
  const lastWeight = completedSets[0].weight;

  if (allSetsSucceededMax) {
    // Increment weight
    const increment = lastWeight >= 50 ? 5 : 2.5;
    return {
      suggestedWeight: lastWeight + increment,
      reason: `Excelente! Você atingiu o limite máximo de ${targetMaxReps} reps em todas as séries com ${lastWeight}kg. Suba a carga!`,
      action: 'increase',
    };
  }

  if (allSetsSucceededMin) {
    return {
      suggestedWeight: lastWeight,
      reason: `Bom trabalho! Você concluiu as séries dentro da faixa recomendada (${exercise.repsRange}) com ${lastWeight}kg. Mantenha para consolidar a força.`,
      action: 'maintain',
    };
  }

  // Underperformed: if failing consecutive times, suggest decrease, otherwise maintain
  if (consecutiveFailsCount >= 2) {
    const decrement = lastWeight > 10 ? (lastWeight >= 50 ? 5 : 2.5) : 0;
    return {
      suggestedWeight: Math.max(2, lastWeight - decrement),
      reason: `Alerta de estagnação: você falhou em alcançar ${targetMinReps} reps por ${consecutiveFailsCount} treinos seguidos. Reduza um pouco a carga para focar na execução.`,
      action: 'decrease',
    };
  }

  return {
    suggestedWeight: lastWeight,
    reason: `Você ficou um pouco abaixo das repetições mínimas (${targetMinReps}) em algumas séries. Sugerimos manter ${lastWeight}kg e focar na progressão de repetições.`,
    action: 'maintain',
  };
}

/**
 * Seed initial premium workouts matching the Hevy/Spotify look and feel.
 */
export function getInitialWorkouts(): Workout[] {
  return [
    {
      id: 'upper_a',
      name: 'Treino A - Superior (Upper)',
      isActive: true,
      exercises: [
        {
          id: 'u_1',
          exerciseId: 'supino_inclinado',
          name: 'Supino Inclinado com Halteres',
          primaryMuscle: 'Peito',
          setsCount: 4,
          repsRange: '6-8',
          restTime: 90,
          targetWeight: 22,
          notes: 'Foco na cadência de descida de 3 segundos.',
        },
        {
          id: 'u_2',
          exerciseId: 'remada_maquina',
          name: 'Remada Baixa Máquina (ou Cabo)',
          primaryMuscle: 'Costas',
          setsCount: 3,
          repsRange: '10',
          restTime: 60,
          targetWeight: 45,
          notes: 'Espremer bem as escápulas no final.',
        },
        {
          id: 'u_3',
          exerciseId: 'supino_reto',
          name: 'Supino Reto com Barra',
          primaryMuscle: 'Peito',
          setsCount: 3,
          repsRange: '8',
          restTime: 90,
          targetWeight: 60,
          notes: 'Controlar o toque leve no peitoral.',
        },
        {
          id: 'u_4',
          exerciseId: 'puxada_triangulo',
          name: 'Puxada Pulley com Triângulo',
          primaryMuscle: 'Costas',
          setsCount: 3,
          repsRange: '10',
          restTime: 60,
          targetWeight: 50,
          notes: 'Trazer na linha superior do peito.',
        },
        {
          id: 'u_5',
          exerciseId: 'elevacao_lateral',
          name: 'Elevação Lateral com Halteres',
          primaryMuscle: 'Ombro',
          setsCount: 3,
          repsRange: '12',
          restTime: 60,
          targetWeight: 8,
          notes: 'Foco no deltoide lateral, sem impulso.',
        },
        {
          id: 'u_6',
          exerciseId: 'rosca_scott',
          name: 'Rosca Scott com Barra W',
          primaryMuscle: 'Bíceps',
          setsCount: 3,
          repsRange: '10',
          restTime: 60,
          targetWeight: 24,
          notes: 'Evitar travar os cotovelos embaixo.',
        },
        {
          id: 'u_7',
          exerciseId: 'triceps_testa',
          name: 'Tríceps Testa com Barra W',
          primaryMuscle: 'Tríceps',
          setsCount: 3,
          repsRange: '10',
          restTime: 60,
          targetWeight: 18,
          notes: 'Manter os cotovelos paralelos.',
        }
      ],
    },
    {
      id: 'lower_b',
      name: 'Treino B - Inferior (Lower)',
      isActive: false,
      exercises: [
        {
          id: 'l_1',
          exerciseId: 'agachamento_livre',
          name: 'Agachamento Livre com Barra',
          primaryMuscle: 'Pernas',
          setsCount: 4,
          repsRange: '6-8',
          restTime: 120,
          targetWeight: 80,
          notes: 'Atingir profundidade paralela ao chão.',
        },
        {
          id: 'l_2',
          exerciseId: 'leg_press_45',
          name: 'Leg Press 45 Graus',
          primaryMuscle: 'Pernas',
          setsCount: 3,
          repsRange: '10-12',
          restTime: 90,
          targetWeight: 160,
          notes: 'Não tirar o quadril do banco de jeito nenhum.',
        },
        {
          id: 'l_3',
          exerciseId: 'cadeira_extensora',
          name: 'Cadeira Extensora',
          primaryMuscle: 'Pernas',
          setsCount: 3,
          repsRange: '12',
          restTime: 60,
          targetWeight: 40,
          notes: 'Segurar 1 segundo de isometria no topo.',
        },
        {
          id: 'l_4',
          exerciseId: 'mesa_flexora',
          name: 'Mesa Flexora (Cadeira/Mesa)',
          primaryMuscle: 'Pernas',
          setsCount: 3,
          repsRange: '10-12',
          restTime: 60,
          targetWeight: 30,
          notes: 'Contrair e esticar de forma controlada.',
        },
        {
          id: 'l_5',
          exerciseId: 'panturrilha_gemeos',
          name: 'Panturrilha em Pé (Gêmeos)',
          primaryMuscle: 'Pernas',
          setsCount: 4,
          repsRange: '15',
          restTime: 45,
          targetWeight: 50,
          notes: 'Amplitude total e alongamento máximo.',
        }
      ],
    }
  ];
}
