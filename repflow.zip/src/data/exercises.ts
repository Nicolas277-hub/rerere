import { Exercise } from '../types';

export const exercisesDatabase: Exercise[] = [
  // PEITO (Peito)
  {
    id: 'supino_inclinado',
    name: 'Supino Inclinado com Halteres',
    primaryMuscle: 'Peitoral Maior (Superior)',
    secondaryMuscle: 'Deltoide Anterior, Tríceps Braquial',
    equipment: 'Halteres, Banco Inclinado',
    difficulty: 'Intermediário',
    category: 'Peito',
    instructions: [
      'Ajuste o banco em uma inclinação de 30 a 45 graus.',
      'Sente-se com um halter em cada coxa e deite-se para trás, erguendo os halteres até a altura dos ombros.',
      'Empurre os halteres para cima de forma controlada até estender os braços, sem travar os cotovelos.',
      'Desça lentamente até sentir o alongamento do peito, mantendo os cotovelos a cerca de 45 graus do corpo.',
    ],
    commonMistakes: [
      'Bater os halteres no topo do movimento.',
      'Cotovelos excessivamente abertos em 90 graus, sobrecarregando o ombro.',
      'Balançar excessivamente os pés ou tirar o quadril do banco.',
    ],
    tips: [
      'Mantenha as escápulas retraídas e contraídas contra o banco durante todo o exercício.',
      'Abaixe os halteres até que fiquem alinhados com a parte superior do peito.',
    ],
  },
  {
    id: 'supino_reto',
    name: 'Supino Reto com Barra',
    primaryMuscle: 'Peitoral Maior (Médio/Geral)',
    secondaryMuscle: 'Deltoide Anterior, Tríceps Braquial',
    equipment: 'Barra, Banco Reto',
    difficulty: 'Intermediário',
    category: 'Peito',
    instructions: [
      'Deite-se de costas em um banco plano com os pés firmes no chão.',
      'Segure a barra com pegada pronada, ligeiramente mais larga que os ombros.',
      'Retire a barra do suporte e posicione-a sobre a linha média do peito.',
      'Desça a barra de forma controlada até tocar suavemente o meio do peitoral.',
      'Empurre a barra de volta à posição inicial com força.',
    ],
    commonMistakes: [
      'Bater a barra com força contra o peito.',
      'Retirar os pés do chão durante o esforço.',
      'Estender excessivamente os cotovelos gerando impacto articular.',
    ],
    tips: [
      'Mantenha os cotovelos alinhados sob os punhos.',
      'Foque em empurrar as costas contra o banco para máxima estabilidade.',
    ],
  },
  {
    id: 'crucifixo_maquina',
    name: 'Crucifixo Máquina (Pec Deck)',
    primaryMuscle: 'Peitoral Maior',
    secondaryMuscle: 'Deltoide Anterior',
    equipment: 'Máquina Pec Deck',
    difficulty: 'Iniciante',
    category: 'Peito',
    instructions: [
      'Ajuste a altura do banco para que os braços fiquem paralelos ao chão.',
      'Sente-se apoiando totalmente as costas no encosto.',
      'Segure as manoplas mantendo uma leve flexão nos cotovelos.',
      'Aproxime as mãos até que se encontrem na frente do corpo, espremendo o peitoral.',
      'Retorne lentamente à posição inicial controlando a carga.',
    ],
    commonMistakes: [
      'Utilizar o impulso do corpo ou projetar os ombros para a frente.',
      'Fazer movimentos rápidos e sem contração isométrica no pico de contração.',
    ],
    tips: [
      'Mantenha os ombros baixos e para trás.',
      'Sinta o peitoral trabalhar ativamente, mentalizando a contração do músculo.',
    ],
  },
  {
    id: 'supino_maquina_hammer',
    name: 'Supino Máquina Hammer',
    primaryMuscle: 'Peitoral Maior',
    secondaryMuscle: 'Tríceps Braquial, Deltoide Anterior',
    equipment: 'Máquina articulada',
    difficulty: 'Iniciante',
    category: 'Peito',
    instructions: [
      'Ajuste o assento para que os pegadores fiquem na linha do peitoral médio.',
      'Mantenha as costas e cabeça apoiadas firmemente.',
      'Empurre as manoplas para a frente estendendo os braços.',
      'Retorne de forma lenta até a posição inicial sem deixar as placas baterem.',
    ],
    commonMistakes: [
      'Não realizar a amplitude máxima.',
      'Deixar os cotovelos subirem acima da linha dos ombros.',
    ],
    tips: [
      'Excelente opção para falha muscular segura sem risco de queda de peso.',
    ],
  },

  // COSTAS (Costas)
  {
    id: 'puxada_triangulo',
    name: 'Puxada Pulley com Triângulo',
    primaryMuscle: 'Latíssimo do Dorso (Grande Dorsal)',
    secondaryMuscle: 'Bíceps Braquial, Redondo Maior, Trapezius',
    equipment: 'Polia Alta, Pegador Triângulo',
    difficulty: 'Iniciante',
    category: 'Costas',
    instructions: [
      'Prenda o pegador triângulo na polia alta.',
      'Sente-se de frente para a máquina e ajuste os apoios de coxa firmemente.',
      'Segure o triângulo e incline levemente o tronco para trás (cerca de 10-15 graus).',
      'Puxe o triângulo em direção ao peitoral superior, trazendo os cotovelos para baixo e para trás.',
      'Estenda os braços de forma controlada, sentindo alongar as costas.',
    ],
    commonMistakes: [
      'Dar solavancos excessivos com o tronco para puxar a carga.',
      'Trazer o pegador na barriga ao invés de no peitoral superior.',
      'Não esticar totalmente os braços no topo.',
    ],
    tips: [
      'Inicie o movimento puxando pelas escápulas (depressão escapular) antes de dobrar os braços.',
      'Imagine que seus braços são apenas ganchos e puxe diretamente pelos cotovelos.',
    ],
  },
  {
    id: 'remada_maquina',
    name: 'Remada Baixa Máquina (ou Cabo)',
    primaryMuscle: 'Latíssimo do Dorso, Romboide',
    secondaryMuscle: 'Bíceps Braquial, Deltoide Posterior',
    equipment: 'Polia Baixa / Máquina',
    difficulty: 'Iniciante',
    category: 'Costas',
    instructions: [
      'Sente-se na máquina com os pés firmes nas plataformas de apoio.',
      'Mantenha a coluna ereta e joelhos levemente flexionados.',
      'Segure o pegador duplo e puxe em direção ao abdômen inferior.',
      'Aperte as escápulas uma contra a outra no ponto de máxima contração.',
      'Retorne esticando totalmente os braços de maneira controlada.',
    ],
    commonMistakes: [
      'Curvar as costas (coluna em cifose) durante a execução.',
      'Girar excessivamente o tronco ou fazer uso exagerado de impulso.',
    ],
    tips: [
      'Mantenha o peito aberto e elevado.',
      'Concentre a força nas costas, e não no aperto das mãos.',
    ],
  },
  {
    id: 'puxada_frontal',
    name: 'Puxada Pulley Aberta',
    primaryMuscle: 'Latíssimo do Dorso',
    secondaryMuscle: 'Bíceps Braquial, Redondo Maior, Deltoide Posterior',
    equipment: 'Polia Alta, Barra Longa',
    difficulty: 'Iniciante',
    category: 'Costas',
    instructions: [
      'Segure a barra longa com pegada pronada bem aberta.',
      'Sente-se posicionando os joelhos abaixo dos rolos protetores.',
      'Puxe a barra em direção ao peito alto, direcionando os cotovelos para as costelas.',
      'Controle a subida até a extensão completa dos braços.',
    ],
    commonMistakes: [
      'Puxar a barra por trás do pescoço (risco de lesão no ombro).',
      'Inclinar excessivamente o tronco para trás transformando em remada.',
    ],
    tips: [
      'Foque na descida dos cotovelos para ativar melhor a musculatura das costas.',
    ],
  },
  {
    id: 'remada_curvada',
    name: 'Remada Curvada com Barra',
    primaryMuscle: 'Grande Dorsal, Romboides, Redondos',
    secondaryMuscle: 'Bíceps Braquial, Eretores da Espinha',
    equipment: 'Barra',
    difficulty: 'Avançado',
    category: 'Costas',
    instructions: [
      'Segure a barra com pegada pronada ou supinada à largura dos ombros.',
      'Flexione levemente os joelhos e incline o tronco para a frente (cerca de 45 graus) mantendo a coluna neutra.',
      'Puxe a barra até a altura do umbigo, espremendo as escápulas.',
      'Abaixe a barra lentamente até a posição inicial.',
    ],
    commonMistakes: [
      'Arredondar a coluna lombar (altíssimo risco de lesão).',
      'Fazer movimentos de balanço vertical para compensar o peso.',
    ],
    tips: [
      'Mantenha o core extremamente contraído durante toda a série.',
    ],
  },

  // OMBRO (Ombro)
  {
    id: 'elevacao_lateral',
    name: 'Elevação Lateral com Halteres',
    primaryMuscle: 'Deltoide Lateral (Ombro)',
    secondaryMuscle: 'Deltoide Anterior, Trapézio',
    equipment: 'Halteres',
    difficulty: 'Iniciante',
    category: 'Ombro',
    instructions: [
      'Fique em pé com a coluna ereta, segurando os halteres ao lado do corpo.',
      'Incline ligeiramente o tronco para a frente (cerca de 5 graus).',
      'Eleve os halteres para os lados em um arco, mantendo os cotovelos levemente flexionados.',
      'Suba até a altura dos ombros e depois abaixe de volta de forma lenta.',
    ],
    commonMistakes: [
      'Usar impulso com as pernas ou costas.',
      'Subir os braços acima da linha dos ombros de forma descontrolada.',
      'Apontar os polegares para cima no topo (ativa mais o deltoide anterior).',
    ],
    tips: [
      'Pense em "jogar os halteres para longe" e não para cima.',
      'Mantenha a palma da mão voltada para o chão ou polegar ligeiramente apontado para baixo.',
    ],
  },
  {
    id: 'desenvolvimento_militar',
    name: 'Desenvolvimento com Halteres',
    primaryMuscle: 'Deltoide Anterior',
    secondaryMuscle: 'Tríceps Braquial, Deltoide Lateral',
    equipment: 'Banco, Halteres',
    difficulty: 'Intermediário',
    category: 'Ombro',
    instructions: [
      'Sente-se em um banco com encosto vertical de 90 graus.',
      'Eleve os halteres até a linha dos ombros, palmas das mãos voltadas para a frente.',
      'Empurre os halteres para cima até esticar quase totalmente os braços.',
      'Desça de maneira controlada até que os halteres fiquem próximos à orelha ou ombros.',
    ],
    commonMistakes: [
      'Arquear excessivamente a lombar saindo do encosto do banco.',
      'Colidir os halteres no topo.',
    ],
    tips: [
      'Mantenha os cotovelos levemente projetados para a frente em vez de totalmente abertos para preservar a articulação.',
    ],
  },
  {
    id: 'crucifixo_inverso',
    name: 'Crucifixo Inverso com Halteres',
    primaryMuscle: 'Deltoide Posterior',
    secondaryMuscle: 'Trapezius, Romboides',
    equipment: 'Halteres',
    difficulty: 'Intermediário',
    category: 'Ombro',
    instructions: [
      'Incline o tronco para a frente mantendo as costas retas, quase paralelas ao chão.',
      'Segure os halteres apontados para baixo com pegada neutra.',
      'Eleve os halteres para as laterais abrindo os braços com cotovelos semicurvados.',
      'Contraia a porção posterior dos ombros e retorne lentamente.',
    ],
    commonMistakes: [
      'Fazer movimentos de pêndulo rápido usando a coluna.',
      'Dobrar excessivamente os cotovelos transformando em remada.',
    ],
    tips: [
      'Foque em direcionar os cotovelos para o teto.',
    ],
  },

  // BÍCEPS (Bíceps)
  {
    id: 'rosca_scott',
    name: 'Rosca Scott com Barra W',
    primaryMuscle: 'Bíceps Braquial',
    secondaryMuscle: 'Braquial, Braquiorradial',
    equipment: 'Banco Scott, Barra W',
    difficulty: 'Intermediário',
    category: 'Bíceps',
    instructions: [
      'Ajuste o banco Scott para que suas axilas fiquem encaixadas perfeitamente no suporte.',
      'Segure a barra W nas curvaturas internas com pegada supinada.',
      'Apoie os tríceps completamente no estofado, sem levantar os braços durante o exercício.',
      'Flexione os braços trazendo a barra em direção aos ombros de forma controlada.',
      'Desça a barra lentamente até quase a extensão completa dos cotovelos.',
    ],
    commonMistakes: [
      'Esticar os cotovelos bruscamente no final da descida (perigo de estiramento ou ruptura).',
      'Retirar os cotovelos do estofado ao cansar.',
      'Subir demais a barra a ponto de perder a tensão muscular.',
    ],
    tips: [
      'Evite o bloqueio articular completo no fundo; pare um instante antes para manter o bíceps sob tensão contínua.',
      'Use a barra W para diminuir o estresse nos punhos.',
    ],
  },
  {
    id: 'rosca_direta_halteres',
    name: 'Rosca Alternada com Halteres',
    primaryMuscle: 'Bíceps Braquial',
    secondaryMuscle: 'Braquiorradial, Antebraço',
    equipment: 'Halteres',
    difficulty: 'Iniciante',
    category: 'Bíceps',
    instructions: [
      'Fique em pé segurando um halter em cada mão ao lado das coxas.',
      'Flexione um braço rotacionando o punho para cima (supinação) durante o movimento.',
      'Contraia o bíceps no topo por 1 segundo.',
      'Desça o halter controladamente enquanto inicia o movimento com o outro braço.',
    ],
    commonMistakes: [
      'Balançar o corpo para frente e para trás para levantar o peso.',
      'Levar o cotovelo muito para a frente, dissipando a força do bíceps para o ombro.',
    ],
    tips: [
      'Mantenha os cotovelos fixados firmemente nas laterais do tronco.',
    ],
  },
  {
    id: 'rosca_martelo',
    name: 'Rosca Martelo com Halteres',
    primaryMuscle: 'Braquiorradial (Antebraço)',
    secondaryMuscle: 'Bíceps Braquial',
    equipment: 'Halteres',
    difficulty: 'Iniciante',
    category: 'Bíceps',
    instructions: [
      'Fique em pé ou sentado, segurando os halteres com pegada neutra (palmas voltadas uma para a outra).',
      'Eleve os halteres flexionando os braços, mantendo as palmas das mãos voltadas para dentro.',
      'Aperte a musculatura e retorne de forma gradual ao ponto inicial.',
    ],
    commonMistakes: [
      'Utilizar impulso excessivo com os quadris.',
    ],
    tips: [
      'Excelente exercício para desenvolver a espessura do braço e força de pegada.',
    ],
  },

  // TRÍCEPS (Tríceps)
  {
    id: 'triceps_testa',
    name: 'Tríceps Testa com Barra W',
    primaryMuscle: 'Tríceps Braquial (Cabeça Longa/Geral)',
    secondaryMuscle: 'Antebraço',
    equipment: 'Banco Reto, Barra W',
    difficulty: 'Intermediário',
    category: 'Tríceps',
    instructions: [
      'Deite-se em um banco reto segurando a barra W na porção interna.',
      'Estenda os braços verticalmente sobre a linha do peito ou ligeiramente inclinados para trás.',
      'Flexione apenas os cotovelos, descendo a barra lentamente em direção à testa ou logo atrás da cabeça.',
      'Empurre a barra de volta à posição inicial utilizando exclusivamente a força do tríceps.',
    ],
    commonMistakes: [
      'Abrir demais os cotovelos para as laterais durante a descida.',
      'Mover os ombros (braços) para frente e para trás, usando impulso de peito/ombro.',
      'Deixar a barra descer rápido demais correndo o risco de colisão.',
    ],
    tips: [
      'Incline levemente os braços para trás (cerca de 10-15 graus) em relação à vertical para manter os tríceps sob tensão constante mesmo no topo.',
      'Mantenha os cotovelos apontados para a frente.',
    ],
  },
  {
    id: 'triceps_pulley',
    name: 'Tríceps Corda no Pulley',
    primaryMuscle: 'Tríceps Braquial (Cabeça Lateral e Medial)',
    secondaryMuscle: 'Antebraço',
    equipment: 'Polia Alta, Corda',
    difficulty: 'Iniciante',
    category: 'Tríceps',
    instructions: [
      'Prenda a corda na polia alta.',
      'Segure as pontas da corda, dê um pequeno passo para trás e incline levemente o quadril.',
      'Empurre a corda para baixo estendendo totalmente os cotovelos.',
      'No final da extensão, afaste as pontas da corda para fora contraindo o tríceps.',
      'Retorne devagar controlando a flexão dos cotovelos.',
    ],
    commonMistakes: [
      'Deixar os ombros subirem ou curvar a coluna lombar.',
      'Mover os braços de trás para frente usando o peso do corpo.',
    ],
    tips: [
      'Mantenha os cotovelos travados ao lado das costelas durante toda a execução.',
    ],
  },
  {
    id: 'triceps_coice',
    name: 'Tríceps Coice com Halter',
    primaryMuscle: 'Tríceps Braquial',
    secondaryMuscle: 'Deltoide Posterior',
    equipment: 'Halter',
    difficulty: 'Intermediário',
    category: 'Tríceps',
    instructions: [
      'Apoie um joelho e a mão do mesmo lado em um banco plano.',
      'Incline o tronco paralelo ao chão.',
      'Segure o halter com a outra mão, trazendo o cotovelo até a linha do tronco.',
      'Estenda o cotovelo totalmente para trás, erguendo o halter.',
      'Retorne à posição de 90 graus de forma cadenciada.',
    ],
    commonMistakes: [
      'Balançar o braço inteiro em vez de mover apenas o cotovelo.',
    ],
    tips: [
      'Foque na contração total no ponto mais alto.',
    ],
  },

  // PERNAS (Pernas)
  {
    id: 'agachamento_livre',
    name: 'Agachamento Livre com Barra',
    primaryMuscle: 'Quadríceps',
    secondaryMuscle: 'Glúteo Máximo, Isquiotibiais, Eretores da Espinha',
    equipment: 'Barra, Rack de Agachamento',
    difficulty: 'Avançado',
    category: 'Pernas',
    instructions: [
      'Posicione a barra no rack sobre a musculatura do trapézio (não nas vértebras cervicais).',
      'Afaste os pés à largura dos ombros, pontas apontadas levemente para fora.',
      'Retire a barra do suporte e dê um passo para trás.',
      'Inicie a descida projetando os quadris para trás e flexionando os joelhos, como se fosse sentar em uma cadeira.',
      'Agache até que as coxas fiquem pelo menos paralelas ao chão, mantendo a coluna alinhada.',
      'Empurre pelo meio dos pés para retornar à posição ereta.',
    ],
    commonMistakes: [
      'Deixar os joelhos colapsarem para dentro (valgo dinâmico).',
      'Arredondar a região lombar no fundo do agachamento.',
      'Tirar os calcanhares do chão.',
    ],
    tips: [
      'Mantenha o peito aberto e olhe para a frente.',
      'Ative fortemente o abdômen para proteger a lombar.',
    ],
  },
  {
    id: 'leg_press_45',
    name: 'Leg Press 45 Graus',
    primaryMuscle: 'Quadríceps',
    secondaryMuscle: 'Glúteos, Isquiotibiais, Panturrilhas',
    equipment: 'Máquina Leg Press 45',
    difficulty: 'Intermediário',
    category: 'Pernas',
    instructions: [
      'Sente-se no aparelho e posicione os pés na plataforma à largura dos ombros.',
      'Destrave a trava de segurança e segure firmemente as alças laterais.',
      'Flexione os joelhos trazendo a plataforma em direção ao peito, sem retirar o quadril do encosto.',
      'Empurre a plataforma de volta sem travar totalmente os joelhos no topo.',
    ],
    commonMistakes: [
      'Tirar a bacia/lombar do assento (alto risco de herniação discal).',
      'Amplitude extremamente curta com peso excessivo.',
      'Esticar totalmente as pernas travando as articulações dos joelhos.',
    ],
    tips: [
      'Mantenha o quadril colado no banco durante todo o exercício.',
    ],
  },
  {
    id: 'cadeira_extensora',
    name: 'Cadeira Extensora',
    primaryMuscle: 'Quadríceps (Foco no Reto Femoral)',
    secondaryMuscle: 'Nenhum',
    equipment: 'Cadeira Extensora',
    difficulty: 'Iniciante',
    category: 'Pernas',
    instructions: [
      'Ajuste o encosto para apoiar totalmente as costas.',
      'Ajuste o rolo de espuma sobre a parte superior dos pés (logo acima do tornozelo).',
      'Segure firme nas manoplas laterais para estabilizar o quadril.',
      'Estenda as pernas completamente, contraindo os quadríceps no topo.',
      'Desça o peso lentamente segurando a fase excêntrica.',
    ],
    commonMistakes: [
      'Não realizar amplitude completa.',
      'Chutar o peso rápido demais sem controle de descida.',
    ],
    tips: [
      'Excelente opção para isolar e fadigar o quadríceps ao máximo.',
    ],
  },
  {
    id: 'mesa_flexora',
    name: 'Mesa Flexora (Cadeira/Mesa)',
    primaryMuscle: 'Isquiotibiais (Posterior de Coxa)',
    secondaryMuscle: 'Panturrilhas, Glúteos',
    equipment: 'Mesa Flexora',
    difficulty: 'Iniciante',
    category: 'Pernas',
    instructions: [
      'Deite-se de bruços ajustando os rolos logo abaixo das panturrilhas.',
      'Mantenha o osso do quadril apoiado no banco.',
      'Flexione os joelhos puxando os rolos em direção ao glúteo.',
      'Retorne lentamente à posição inicial, estendendo as pernas.',
    ],
    commonMistakes: [
      'Levantar excessivamente o quadril do banco para ajudar no movimento.',
    ],
    tips: [
      'Foque na contração máxima de trás da perna.',
    ],
  },
  {
    id: 'panturrilha_gemeos',
    name: 'Panturrilha em Pé (Gêmeos)',
    primaryMuscle: 'Gastrocnêmio, Sóleo',
    secondaryMuscle: 'Nenhum',
    equipment: 'Máquina de Panturrilha / Degrau',
    difficulty: 'Iniciante',
    category: 'Pernas',
    instructions: [
      'Posicione a ponta dos pés na borda do degrau ou suporte da máquina.',
      'Abaixe o calcanhar o máximo possível para alongar a panturrilha.',
      'Empurre o corpo para cima estendendo ao máximo o tornozelo (ponta do pé).',
      'Segure 1 segundo no topo e repita lentamente.',
    ],
    commonMistakes: [
      'Fazer movimentos de mola curtos e rápidos sem usar toda a amplitude.',
    ],
    tips: [
      'Foque no alongamento máximo no fundo do movimento.',
    ],
  }
];
