import React, { useState, useEffect } from 'react';
import { 
  Dumbbell, Bot, ClipboardList, Settings, Sparkles, Flame, Clock, 
  SkipForward, Plus, Minus, CheckCircle, Volume2 
} from 'lucide-react';
import { Workout, WorkoutExercise, ExerciseLog, SetLog, AppState } from './types';
import { getInitialWorkouts } from './utils/progression';
import BottomNav from './components/BottomNav';
import ActiveWorkout from './components/ActiveWorkout';
import ExerciseDetailModal from './components/ExerciseDetailModal';
import CoachIA from './components/CoachIA';
import WorkoutManager from './components/WorkoutManager';
import ConfigTab from './components/ConfigTab';

// Audio and Vibration helper triggers
function playTimerBeep() {
  try {
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(800, audioCtx.currentTime); // High pitch beep
    gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
    
    oscillator.start();
    setTimeout(() => {
      oscillator.stop();
      audioCtx.close();
    }, 400);
  } catch (e) {
    console.error('Audio beep is blocked or unsupported:', e);
  }
}

function triggerVibration() {
  try {
    if (navigator.vibrate) {
      navigator.vibrate([150, 100, 150]);
    }
  } catch (e) {
    console.error('Vibrate is unsupported:', e);
  }
}

export default function App() {
  // 1. Initial State Syncing
  const [workouts, setWorkouts] = useState<Workout[]>(() => {
    const local = localStorage.getItem('repflow_workouts');
    if (local) {
      try { return JSON.parse(local); } catch (e) { console.error(e); }
    }
    return getInitialWorkouts();
  });

  const [history, setHistory] = useState<ExerciseLog[]>(() => {
    const local = localStorage.getItem('repflow_history');
    if (local) {
      try { return JSON.parse(local); } catch (e) { console.error(e); }
    }
    return [];
  });

  // Navigation tab
  const [activeTab, setActiveTab] = useState<'treino' | 'coach' | 'treinos' | 'config'>('treino');

  // Workout Session states
  const [completedExercises, setCompletedExercises] = useState<Record<string, boolean>>(() => {
    const local = localStorage.getItem('repflow_completed_exercises');
    return local ? JSON.parse(local) : {};
  });
  
  const [currentHighlightedId, setCurrentHighlightedId] = useState<string | null>(() => {
    return localStorage.getItem('repflow_highlighted_id');
  });

  const [selectedExercise, setSelectedExercise] = useState<WorkoutExercise | null>(null);

  // Active Rest Timer state
  const [restRemaining, setRestRemaining] = useState<number>(0);
  const [initialRestDuration, setInitialRestDuration] = useState<number>(0);

  // 2. Local Storage Sync Side Effects
  useEffect(() => {
    localStorage.setItem('repflow_workouts', JSON.stringify(workouts));
  }, [workouts]);

  useEffect(() => {
    localStorage.setItem('repflow_history', JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    localStorage.setItem('repflow_completed_exercises', JSON.stringify(completedExercises));
  }, [completedExercises]);

  useEffect(() => {
    if (currentHighlightedId) {
      localStorage.setItem('repflow_highlighted_id', currentHighlightedId);
    } else {
      localStorage.removeItem('repflow_highlighted_id');
    }
  }, [currentHighlightedId]);

  // Find currently active workout
  const activeWorkout = workouts.find((w) => w.isActive) || null;

  // Initialize highlight to first exercise of routine if none set
  useEffect(() => {
    if (activeWorkout && !currentHighlightedId && activeWorkout.exercises.length > 0) {
      setCurrentHighlightedId(activeWorkout.exercises[0].id);
    }
  }, [activeWorkout, currentHighlightedId]);

  // 3. Active Rest Timer ticking loop
  useEffect(() => {
    if (restRemaining <= 0) return;

    const interval = setInterval(() => {
      setRestRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          playTimerBeep();
          triggerVibration();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [restRemaining]);

  // Timer actions
  const handleStartRest = (duration: number) => {
    if (duration <= 0) return;
    setInitialRestDuration(duration);
    setRestRemaining(duration);
  };

  const handleAdjustTimer = (seconds: number) => {
    setRestRemaining((prev) => Math.max(0, prev + seconds));
  };

  const handleSkipTimer = () => {
    setRestRemaining(0);
  };

  // Format countdown string
  const formatTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 4. Workout Session updates and logging
  const handleSaveExerciseLogs = (exerciseId: string, sets: SetLog[], notes: string) => {
    if (!activeWorkout) return;

    const completedSets = sets.filter((s) => s.completed);
    if (completedSets.length === 0) return;

    // Save logs to history
    const exInstance = activeWorkout.exercises.find((ex) => ex.id === exerciseId);
    if (!exInstance) return;

    const newLog: ExerciseLog = {
      id: 'log_' + Date.now(),
      workoutId: activeWorkout.id,
      exerciseId: exInstance.exerciseId,
      exerciseName: exInstance.name,
      date: new Date().toISOString().slice(0, 10), // YYYY-MM-DD
      sets: completedSets,
      notes: notes || undefined,
    };

    setHistory((prev) => [newLog, ...prev]);

    // Update completion state
    setCompletedExercises((prev) => ({
      ...prev,
      [exerciseId]: true,
    }));

    // Save target weight to workouts to keep progress updated!
    const updatedWorkouts = workouts.map((w) => {
      if (w.id === activeWorkout.id) {
        const updatedExercises = w.exercises.map((ex) => {
          if (ex.id === exerciseId) {
            // Update base target weight to the heaviest completed set weight
            const heaviestWeight = completedSets.reduce((max, curr) => curr.weight > max ? curr.weight : max, ex.targetWeight || 0);
            return { ...ex, targetWeight: heaviestWeight, notes: notes || ex.notes };
          }
          return ex;
        });
        return { ...w, exercises: updatedExercises };
      }
      return w;
    });
    setWorkouts(updatedWorkouts);

    // Auto highlight the next exercise
    const currentIndex = activeWorkout.exercises.findIndex((ex) => ex.id === exerciseId);
    if (currentIndex >= 0 && currentIndex < activeWorkout.exercises.length - 1) {
      setCurrentHighlightedId(activeWorkout.exercises[currentIndex + 1].id);
    } else {
      setCurrentHighlightedId(null);
    }
  };

  // Conclude the current workout
  const handleFinishWorkout = () => {
    if (!activeWorkout) return;
    
    // Clear active states
    setCompletedExercises({});
    setCurrentHighlightedId(activeWorkout.exercises.length > 0 ? activeWorkout.exercises[0].id : null);
    
    // Notify user with elegant alert
    alert(`Parabéns! Você concluiu o treino "${activeWorkout.name}" com sucesso e salvou sua evolução no histórico. 🏆`);
    
    // Go to history/settings tab automatically to celebrate
    setActiveTab('config');
  };

  // Workout manager events
  const handleAddWorkout = (newW: Workout) => {
    setWorkouts((prev) => [...prev, newW]);
  };

  const handleDuplicateWorkout = (id: string) => {
    const target = workouts.find((w) => w.id === id);
    if (!target) return;
    const duplicated: Workout = {
      ...JSON.parse(JSON.stringify(target)),
      id: 'w_dup_' + Date.now(),
      name: `${target.name} (Cópia)`,
      isActive: false,
    };
    setWorkouts((prev) => [...prev, duplicated]);
  };

  const handleDeleteWorkout = (id: string) => {
    const filtered = workouts.filter((w) => w.id !== id);
    // If deleted the active one, make the first one active if available
    let updated = filtered;
    const wasActive = workouts.find((w) => w.id === id)?.isActive;
    if (wasActive && filtered.length > 0) {
      updated = filtered.map((w, idx) => ({ ...w, isActive: idx === 0 }));
    }
    setWorkouts(updated);
  };

  const handleActivateWorkout = (id: string) => {
    const updated = workouts.map((w) => ({
      ...w,
      isActive: w.id === id,
    }));
    setWorkouts(updated);
    
    // Reset active session parameters
    setCompletedExercises({});
    const targetW = workouts.find((w) => w.id === id);
    setCurrentHighlightedId(targetW && targetW.exercises.length > 0 ? targetW.exercises[0].id : null);
    
    // Redirect to training session immediately!
    setActiveTab('treino');
  };

  const handleUpdateWorkout = (updatedW: Workout) => {
    setWorkouts((prev) => prev.map((w) => (w.id === updatedW.id ? updatedW : w)));
  };

  // Backup and Reset callbacks
  const handleImportBackup = (backup: { workouts: Workout[]; history: ExerciseLog[] }) => {
    setWorkouts(backup.workouts);
    setHistory(backup.history);
    setCompletedExercises({});
    const active = backup.workouts.find((w) => w.isActive);
    setCurrentHighlightedId(active && active.exercises.length > 0 ? active.exercises[0].id : null);
  };

  const handleResetApp = () => {
    localStorage.clear();
    setWorkouts(getInitialWorkouts());
    setHistory([]);
    setCompletedExercises({});
    setCurrentHighlightedId(null);
    setActiveTab('treino');
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D] text-white font-sans flex flex-col max-w-xl mx-auto shadow-2xl relative pb-28">
      {/* Upper Brand bar */}
      <header className="px-6 py-5 flex justify-between items-center bg-[#0D0D0D] border-b border-[#1A1A1A] sticky top-0 z-40">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-[#4F8CFF] rounded-xl flex items-center justify-center">
            <span className="text-xl font-bold italic text-black">R</span>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white leading-tight">RepFlow</h1>
            <p className="text-[10px] text-[#4F8CFF] font-medium tracking-widest uppercase">Premium Workout</p>
          </div>
        </div>
        
        {/* Simple offline Indicator */}
        <div className="flex items-center space-x-1.5 bg-[#1A1A1A] border border-[#252525] px-3 py-1.5 rounded-full">
          <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
          <span className="text-[10px] font-bold text-[#888] font-mono uppercase tracking-wider">OFFLINE</span>
        </div>
      </header>

      {/* Main Tab content router */}
      <main className="flex-1 overflow-y-auto pt-1 animate-fade-in">
        {activeTab === 'treino' && (
          <ActiveWorkout
            workout={activeWorkout}
            history={history}
            completedExercises={completedExercises}
            currentHighlightedId={currentHighlightedId}
            onSelectExercise={(ex) => setSelectedExercise(ex)}
            onFinishWorkout={handleFinishWorkout}
            onChangeWorkoutClick={() => setActiveTab('treinos')}
          />
        )}

        {activeTab === 'coach' && (
          <CoachIA
            workouts={workouts}
            history={history}
          />
        )}

        {activeTab === 'treinos' && (
          <WorkoutManager
            workouts={workouts}
            onAddWorkout={handleAddWorkout}
            onDuplicateWorkout={handleDuplicateWorkout}
            onDeleteWorkout={handleDeleteWorkout}
            onActivateWorkout={handleActivateWorkout}
            onUpdateWorkout={handleUpdateWorkout}
          />
        )}

        {activeTab === 'config' && (
          <ConfigTab
            workouts={workouts}
            history={history}
            onImportBackup={handleImportBackup}
            onResetApp={handleResetApp}
          />
        )}
      </main>

      {/* Rest Timer Floating Overlay Banner */}
      {restRemaining > 0 && (
        <div className="fixed bottom-24 left-4 right-4 z-40 bg-black/40 border border-[#4F8CFF]/30 p-6 rounded-[32px] flex items-center justify-between shadow-[0_8px_30px_rgb(0,0,0,0.6)] backdrop-blur-md max-w-[500px] mx-auto animate-slide-up">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-full border-4 border-[#4F8CFF] border-t-transparent flex items-center justify-center relative">
              <Clock className="h-4 w-4 text-[#4F8CFF] absolute opacity-50" />
            </div>
            
            <div>
              <p className="text-sm font-bold text-white mb-0.5">Descansando...</p>
              <p className="text-xl font-bold text-white font-mono tabular-nums leading-none">
                {formatTime(restRemaining)}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleAdjustTimer(-10)}
              className="w-10 h-10 flex items-center justify-center bg-[#252525] hover:bg-[#333] text-[#888] hover:text-white rounded-full transition-colors"
              title="Subtrair 10 segundos"
            >
              <Minus className="h-4 w-4" />
            </button>
            <button
              onClick={() => handleAdjustTimer(10)}
              className="w-10 h-10 flex items-center justify-center bg-[#252525] hover:bg-[#333] text-[#888] hover:text-white rounded-full transition-colors"
              title="Adicionar 10 segundos"
            >
              <Plus className="h-4 w-4" />
            </button>
            <button
              onClick={handleSkipTimer}
              className="px-5 py-2.5 bg-[#252525] hover:bg-[#333] text-white text-xs font-bold rounded-full transition-colors"
            >
              PULAR
            </button>
          </div>
        </div>
      )}

      {/* Exercise detail and logging view popup modal */}
      {selectedExercise && activeWorkout && (
        <ExerciseDetailModal
          exercise={selectedExercise}
          history={history}
          workoutId={activeWorkout.id}
          onClose={() => setSelectedExercise(null)}
          onSaveLogs={handleSaveExerciseLogs}
          onRestStart={handleStartRest}
        />
      )}

      {/* Custom Bottom App Navigation */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          // Let's scroll main layout smoothly to top when switching tabs
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />
    </div>
  );
}
