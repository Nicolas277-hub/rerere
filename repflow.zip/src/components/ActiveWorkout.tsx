import React from 'react';
import { Dumbbell, ArrowRight, CheckCircle2, Play, Circle, Calendar, ClipboardCheck } from 'lucide-react';
import { Workout, WorkoutExercise, ExerciseLog } from '../types';

interface ActiveWorkoutProps {
  workout: Workout | null;
  history: ExerciseLog[];
  completedExercises: Record<string, boolean>; // mapping of exercise instance ID to completion state
  currentHighlightedId: string | null;
  onSelectExercise: (exercise: WorkoutExercise) => void;
  onFinishWorkout: () => void;
  onChangeWorkoutClick: () => void;
}

export default function ActiveWorkout({
  workout,
  history,
  completedExercises,
  currentHighlightedId,
  onSelectExercise,
  onFinishWorkout,
  onChangeWorkoutClick,
}: ActiveWorkoutProps) {
  if (!workout) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center min-h-[60vh]">
        <div className="p-4 bg-[#1A1A1A] rounded-full mb-4">
          <Dumbbell className="h-10 w-10 text-gray-500" />
        </div>
        <h2 className="text-xl font-bold mb-2">Nenhum treino ativo</h2>
        <p className="text-gray-400 text-sm mb-6 max-w-xs">
          Para começar a registrar, ative um treino existente ou crie uma ficha de treino nova.
        </p>
        <button
          onClick={onChangeWorkoutClick}
          className="bg-[#4F8CFF] hover:bg-[#3d7ae6] text-white px-6 py-3 rounded-xl font-bold tracking-wider uppercase transition-all shadow-lg active:scale-95 flex items-center gap-2"
        >
          <ClipboardCheck className="h-5 w-5" />
          Ver Meus Treinos
        </button>
      </div>
    );
  }

  // Calculate workout completion stats
  const totalExercises = workout.exercises.length;
  const completedCount = Object.keys(completedExercises).filter((key) => completedExercises[key]).length;
  const progressPercent = totalExercises > 0 ? Math.round((completedCount / totalExercises) * 100) : 0;

  return (
    <div className="flex flex-col px-6 py-4 space-y-6">
      {/* Header Info */}
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">{workout.name}</h2>
          <span className="text-xs text-[#888] bg-[#1A1A1A] px-2 py-1 rounded mt-2 inline-block">
            {totalExercises} Exercícios
          </span>
        </div>
        
        <button
          onClick={onChangeWorkoutClick}
          className="bg-[#1A1A1A] hover:bg-[#252525] px-4 py-2 rounded-full text-xs font-semibold border border-[#2a2a2a] transition-all text-white"
        >
          Alterar Ficha
        </button>
      </div>

      {/* Progress Bar */}
      <div className="bg-[#1A1A1A] p-4 rounded-2xl border border-white/5">
        <div className="flex justify-between items-center text-[10px] text-[#888] font-bold uppercase tracking-widest mb-2">
          <span>Progresso</span>
          <span className="text-[#4F8CFF]">{completedCount} / {totalExercises} ({progressPercent}%)</span>
        </div>
        <div className="w-full h-1.5 bg-[#252525] rounded-full overflow-hidden">
          <div
            className="h-full bg-[#4F8CFF] transition-all duration-500 rounded-full"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Exercises List */}
      <div className="space-y-3">
        {workout.exercises.length === 0 ? (
          <div className="text-center p-8 bg-[#1A1A1A] rounded-2xl border border-dashed border-[#333]">
            <p className="text-[#888] text-sm font-medium">Este treino não possui exercícios cadastrados.</p>
          </div>
        ) : (
          workout.exercises.map((ex, index) => {
            const isCompleted = completedExercises[ex.id];
            const isHighlighted = ex.id === currentHighlightedId;
            
            return (
              <div
                key={ex.id}
                onClick={() => onSelectExercise(ex)}
                className={`relative cursor-pointer p-4 rounded-2xl flex items-center justify-between group transition-all duration-300 ${
                  isHighlighted
                    ? 'bg-[#4F8CFF] text-white shadow-[0_4px_20px_rgba(79,140,255,0.2)] scale-[1.02]'
                    : isCompleted
                    ? 'bg-[#151515] border border-[#1A1A1A] opacity-50'
                    : 'bg-[#1A1A1A] border border-[#252525] opacity-70 hover:opacity-100'
                }`}
              >
                <div className="flex items-center space-x-3.5">
                  <div>
                    <p className={`text-sm font-bold ${
                      isHighlighted ? 'text-white' : isCompleted ? 'text-[#666] line-through' : 'text-[#888] group-hover:text-white'
                    }`}>
                      {ex.name}
                    </p>
                    <p className={`text-xs mt-1 ${isHighlighted ? 'text-white/80' : 'text-[#666]'}`}>
                      {ex.setsCount}x {ex.repsRange} reps
                    </p>
                  </div>
                </div>

                <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                  isCompleted || isHighlighted
                    ? 'bg-white/20'
                    : 'border-2 border-[#333]'
                }`}>
                  {(isCompleted || isHighlighted) && (
                    <div className="w-2 h-2 bg-white rounded-full" />
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Finish Workout Button */}
      {workout.exercises.length > 0 && (
        <div className="pt-6 pb-12 flex flex-col items-center gap-3">
          <button
            onClick={onFinishWorkout}
            disabled={completedCount === 0}
            className={`w-full py-4 rounded-full font-semibold text-sm transition-all border ${
              completedCount > 0
                ? 'bg-[#1A1A1A] hover:bg-[#252525] border-[#2a2a2a] text-white'
                : 'bg-[#151515] border-[#1A1A1A] text-[#666] cursor-not-allowed'
            }`}
          >
            Concluir Sessão
          </button>
          {completedCount === 0 && (
            <span className="text-xs text-[#666]">
              Toque em um exercício na lista para registrar suas séries.
            </span>
          )}
        </div>
      )}
    </div>
  );
}
