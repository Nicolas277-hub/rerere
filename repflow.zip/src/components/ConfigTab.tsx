import React, { useRef, useState } from 'react';
import { 
  Settings, RotateCcw, Download, Upload, Info, Heart, Award, 
  Dumbbell, Calendar, Flame, Layers, ShieldAlert, CheckCircle2 
} from 'lucide-react';
import { Workout, ExerciseLog, SetLog } from '../types';

interface ConfigTabProps {
  workouts: Workout[];
  history: ExerciseLog[];
  onImportBackup: (backupState: { workouts: Workout[]; history: ExerciseLog[] }) => void;
  onResetApp: () => void;
}

export default function ConfigTab({
  workouts,
  history,
  onImportBackup,
  onResetApp,
}: ConfigTabProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Statistics Calculations
  // 1. Weekly Workouts (last 7 days)
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  const weeklyLogs = history.filter((log) => new Date(log.date) >= oneWeekAgo);
  const weeklyWorkoutsCount = new Set(weeklyLogs.map((log) => log.workoutId + '_' + log.date)).size;

  // 2. Weekly volume (sum of weight * reps for completed sets in the last 7 days)
  let weeklyVolume = 0;
  weeklyLogs.forEach((log) => {
    log.sets.forEach((set) => {
      if (set.completed) {
        weeklyVolume += set.weight * set.reps;
      }
    });
  });

  // 3. Most Trained Muscles (Category frequency share)
  const muscleFrequencies: Record<string, number> = {};
  history.forEach((log) => {
    const muscle = log.sets.length > 0 ? (log.sets.filter(s => s.completed).length > 0 ? log.exerciseName : null) : null;
    // Guess muscle group from name or generic metadata
    const nameLower = log.exerciseName.toLowerCase();
    let group = 'Outros';
    if (nameLower.includes('supino') || nameLower.includes('peito') || nameLower.includes('crucifixo')) group = 'Peito';
    else if (nameLower.includes('puxada') || nameLower.includes('remada') || nameLower.includes('costas')) group = 'Costas';
    else if (nameLower.includes('elevação') || nameLower.includes('desenvolvimento') || nameLower.includes('ombro')) group = 'Ombros';
    else if (nameLower.includes('rosca') || nameLower.includes('biceps') || nameLower.includes('bíceps')) group = 'Bíceps';
    else if (nameLower.includes('testa') || nameLower.includes('triceps') || nameLower.includes('tríceps') || nameLower.includes('corda')) group = 'Tríceps';
    else if (nameLower.includes('agachamento') || nameLower.includes('leg press') || nameLower.includes('extensora') || nameLower.includes('flexora') || nameLower.includes('panturrilha') || nameLower.includes('perna')) group = 'Pernas';

    muscleFrequencies[group] = (muscleFrequencies[group] || 0) + log.sets.filter(s => s.completed).length;
  });

  const sortedMuscles = Object.entries(muscleFrequencies)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  // 4. Personal Records (Max weight lifted per exercise)
  const personalRecords: Record<string, number> = {};
  history.forEach((log) => {
    log.sets.forEach((set) => {
      if (set.completed) {
        const currentMax = personalRecords[log.exerciseName] || 0;
        if (set.weight > currentMax) {
          personalRecords[log.exerciseName] = set.weight;
        }
      }
    });
  });

  const prList = Object.entries(personalRecords)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);

  // EXPORT BACKUP JSON file download
  const handleExportBackup = () => {
    const backupData = {
      version: '1.0',
      workouts,
      history,
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `repflow_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // IMPORT BACKUP JSON file upload
  const handleImportBackupClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.workouts && parsed.history) {
          onImportBackup({
            workouts: parsed.workouts,
            history: parsed.history,
          });
          setImportStatus('Backup importado com sucesso!');
          setTimeout(() => setImportStatus(null), 3000);
        } else {
          throw new Error('Formato de backup inválido.');
        }
      } catch (err) {
        alert('Erro ao importar backup. Verifique se o arquivo JSON é válido.');
      }
    };
    reader.readAsText(file);
  };

  const handleResetClick = () => {
    if (confirm('Tem certeza absoluta de que deseja REDEFINIR o aplicativo? Todos os treinos e o histórico de evolução serão limpos.')) {
      onResetApp();
    }
  };

  return (
    <div className="flex flex-col px-4 py-2 space-y-6">
      
      {/* 1. STATISTICS DASHBOARD (Mostrar apenas informações úteis) */}
      <div className="space-y-3">
        <h2 className="text-xs font-black text-gray-500 uppercase tracking-widest px-1">
          Estatísticas & Performance
        </h2>

        {/* Stats Grid cards */}
        <div className="grid grid-cols-2 gap-3">
          {/* Weekly Workouts count */}
          <div className="bg-[#1A1A1A] p-4 rounded-2xl border border-[#222] flex items-center space-x-3">
            <div className="p-2.5 bg-blue-500/10 text-[#4F8CFF] rounded-xl">
              <Calendar className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] text-gray-500 font-bold block uppercase tracking-wider">Treinos (Semana)</span>
              <p className="text-xl font-black text-white font-mono leading-tight">{weeklyWorkoutsCount}</p>
            </div>
          </div>

          {/* Weekly Volume */}
          <div className="bg-[#1A1A1A] p-4 rounded-2xl border border-[#222] flex items-center space-x-3">
            <div className="p-2.5 bg-orange-500/10 text-orange-400 rounded-xl">
              <Flame className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] text-gray-500 font-bold block uppercase tracking-wider">Volume (Semana)</span>
              <p className="text-xl font-black text-white font-mono leading-tight">{weeklyVolume} <span className="text-xs text-gray-400 font-sans">kg</span></p>
            </div>
          </div>
        </div>

        {/* Muscles Share and PRs list */}
        <div className="bg-[#1A1A1A] p-4.5 rounded-2xl border border-[#222] space-y-3.5">
          {/* Muscle Focus list */}
          <div>
            <span className="text-[9px] uppercase tracking-widest text-gray-500 font-bold block">Grupos Musculares Mais Treinados</span>
            
            {sortedMuscles.length === 0 ? (
              <p className="text-xs text-gray-500 italic mt-2">Nenhum treino registrado ainda.</p>
            ) : (
              <div className="space-y-2 mt-2">
                {sortedMuscles.map(([muscle, count]) => (
                  <div key={muscle} className="flex items-center justify-between text-xs font-medium">
                    <span className="text-gray-300">{muscle}</span>
                    <span className="font-mono text-gray-500">{count} séries feitas</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Personal records List */}
          <div className="border-t border-[#222] pt-3.5">
            <span className="text-[9px] uppercase tracking-widest text-gray-500 font-bold block">Recordes Pessoais (Melhor Carga)</span>
            
            {prList.length === 0 ? (
              <p className="text-xs text-gray-500 italic mt-2">Nenhum recorde registrado ainda.</p>
            ) : (
              <div className="space-y-2 mt-2">
                {prList.map(([exName, weight]) => (
                  <div key={exName} className="flex items-center justify-between text-xs">
                    <span className="text-gray-300 font-medium truncate max-w-[190px]">{exName}</span>
                    <span className="font-mono text-[#4F8CFF] font-black">{weight} kg</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 2. SETTINGS LIST (Configurações) */}
      <div className="space-y-3">
        <h2 className="text-xs font-black text-gray-500 uppercase tracking-widest px-1">
          Configurações do Aplicativo
        </h2>

        <div className="bg-[#1A1A1A] rounded-2xl border border-[#222] overflow-hidden divide-y divide-[#222]">
          
          {/* Tema (Premium dark theme information, clean) */}
          <div className="p-4 flex justify-between items-center text-sm">
            <div>
              <span className="font-bold text-white block">Tema</span>
              <span className="text-xs text-gray-500">Premium Cosmic Dark</span>
            </div>
            <span className="text-[10px] bg-[#1C2638] text-[#4F8CFF] font-black px-2.5 py-1 rounded uppercase tracking-wider font-mono">
              Ativado
            </span>
          </div>

          {/* Idioma */}
          <div className="p-4 flex justify-between items-center text-sm">
            <div>
              <span className="font-bold text-white block">Idioma</span>
              <span className="text-xs text-gray-500">Português (Brasil)</span>
            </div>
            <span className="text-[10px] bg-[#222] text-gray-400 font-bold px-2.5 py-1 rounded uppercase font-mono">
              PT-BR
            </span>
          </div>

          {/* Exportar Backup */}
          <button
            onClick={handleExportBackup}
            className="w-full p-4 flex justify-between items-center hover:bg-[#222]/30 transition-colors text-left"
          >
            <div>
              <span className="font-bold text-white block text-sm">Exportar Backup</span>
              <span className="text-xs text-gray-500">Baixar arquivo de dados JSON da sua evolução</span>
            </div>
            <Download className="h-4 w-4 text-gray-400" />
          </button>

          {/* Importar Backup */}
          <button
            onClick={handleImportBackupClick}
            className="w-full p-4 flex justify-between items-center hover:bg-[#222]/30 transition-colors text-left"
          >
            <div>
              <span className="font-bold text-white block text-sm">Importar Backup</span>
              <span className="text-xs text-gray-500">Restaurar treinos e histórico do arquivo JSON</span>
            </div>
            <Upload className="h-4 w-4 text-gray-400" />
          </button>

          {/* Redefinir Aplicativo */}
          <button
            onClick={handleResetClick}
            className="w-full p-4 flex justify-between items-center hover:bg-red-950/10 transition-colors text-left group"
          >
            <div>
              <span className="font-bold text-red-400 group-hover:text-red-300 block text-sm">Redefinir Aplicativo</span>
              <span className="text-xs text-gray-500">Apagar todos os dados e restaurar ficha padrão</span>
            </div>
            <RotateCcw className="h-4 w-4 text-red-400 group-hover:text-red-300" />
          </button>

        </div>
      </div>

      {/* Hidden File Input for backup importing */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept=".json"
        className="hidden"
      />

      {/* Success Import indicator */}
      {importStatus && (
        <div className="bg-green-950/20 border border-green-900/40 p-3.5 rounded-xl flex items-center space-x-3 text-green-400 animate-fade-in text-xs">
          <CheckCircle2 className="h-5 w-5" />
          <span>{importStatus}</span>
        </div>
      )}

      {/* Footer Branding Info */}
      <div className="pt-4 pb-16 text-center space-y-1">
        <p className="text-[10px] text-gray-600 font-mono tracking-widest uppercase">RepFlow v1.0.0 • Premium Workout Companion</p>
        <p className="text-[9px] text-gray-700">Foco total: abrir, treinar, salvar a evolução.</p>
      </div>

    </div>
  );
}
