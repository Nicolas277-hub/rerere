import React, { useState } from 'react';
import { Search, X, Dumbbell, Star, ChevronDown, ChevronUp, Compass, ShieldAlert, Info, ListFilter, Play } from 'lucide-react';
import { Exercise } from '../types';
import { exercisesDatabase } from '../data/exercises';

interface ExerciseDatabaseModalProps {
  onClose: () => void;
  onSelectExercise?: (exercise: Exercise) => void; // Optional, if used in "select mode" for editor
}

export default function ExerciseDatabaseModal({
  onClose,
  onSelectExercise,
}: ExerciseDatabaseModalProps) {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const categories = ['Todos', 'Peito', 'Costas', 'Ombro', 'Bíceps', 'Tríceps', 'Pernas'];

  const filtered = exercisesDatabase.filter((ex) => {
    const matchesSearch = ex.name.toLowerCase().includes(search.toLowerCase()) ||
                          ex.primaryMuscle.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === 'Todos' || ex.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleToggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-0 sm:p-4 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#0D0D0D] w-full max-w-xl h-full sm:h-[85vh] sm:rounded-2xl border-t sm:border border-[#222] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-[#1A1A1A] flex justify-between items-center bg-[#111]">
          <div>
            <h2 className="text-lg font-black text-white uppercase tracking-wider flex items-center gap-2">
              <Dumbbell className="h-5 w-5 text-[#4F8CFF]" />
              Banco de Exercícios
            </h2>
            <p className="text-[10px] text-gray-500 font-mono mt-0.5">EXPLORE • APRENDA • COPIE</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 bg-[#1A1A1A] hover:bg-[#262626] text-gray-400 hover:text-white rounded-full transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Search & Filter Area */}
        <div className="p-4 bg-[#141414] border-b border-[#1C1C1C] space-y-3.5">
          {/* Search bar */}
          <div className="flex items-center space-x-2 bg-[#1A1A1A] border border-[#222] rounded-xl px-3 py-2.5 focus-within:border-[#4F8CFF] transition-all">
            <Search className="h-4 w-4 text-gray-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Pesquise por nome ou grupo muscular..."
              className="bg-transparent border-0 outline-none text-sm text-white placeholder-gray-600 flex-1"
            />
            {search && (
              <button onClick={() => setSearch('')} className="text-xs text-gray-500 hover:text-white font-mono">
                LIMPAR
              </button>
            )}
          </div>

          {/* Categories bar */}
          <div className="flex overflow-x-auto space-x-1.5 pb-1 scrollbar-none">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`flex-shrink-0 text-xs px-3.5 py-2 rounded-xl font-bold transition-all ${
                    isActive
                      ? 'bg-[#4F8CFF] text-white shadow-md'
                      : 'bg-[#1A1A1A] text-gray-400 hover:text-white hover:bg-[#222]'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Exercise List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
          {filtered.length === 0 ? (
            <div className="text-center p-12 text-gray-500 font-medium">
              Nenhum exercício encontrado para "{search}".
            </div>
          ) : (
            filtered.map((ex) => {
              const isExpanded = expandedId === ex.id;
              return (
                <div
                  key={ex.id}
                  className={`rounded-xl border transition-all overflow-hidden ${
                    isExpanded 
                      ? 'bg-[#161616] border-[#333] shadow-md' 
                      : 'bg-[#1A1A1A] border-[#222] hover:border-[#2b2b2b]'
                  }`}
                >
                  {/* Summary row */}
                  <div
                    onClick={() => handleToggleExpand(ex.id)}
                    className="p-4 flex justify-between items-center cursor-pointer select-none"
                  >
                    <div className="flex items-center space-x-3">
                      {/* Interactive Visual/Icon mimicking exercise animation state */}
                      <div className={`p-2.5 rounded-xl ${isExpanded ? 'bg-[#4F8CFF]/20 text-[#4F8CFF]' : 'bg-[#262626] text-gray-400'}`}>
                        <Dumbbell className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white leading-tight">{ex.name}</h3>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-[10px] font-bold bg-[#1C2638] text-[#4F8CFF] px-2 py-0.5 rounded-md uppercase">
                            {ex.primaryMuscle}
                          </span>
                          {ex.difficulty && (
                            <span className="text-[9px] font-mono text-gray-500 uppercase">
                              {ex.difficulty}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2.5">
                      {onSelectExercise && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectExercise(ex);
                          }}
                          className="bg-[#4F8CFF] hover:bg-[#3d7be6] text-white text-[11px] font-black tracking-wider uppercase px-3 py-1.5 rounded-lg active:scale-95"
                        >
                          Adicionar
                        </button>
                      )}
                      <div className="text-gray-500 hover:text-white transition-colors">
                        {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </div>
                    </div>
                  </div>

                  {/* Expanded instructions panel */}
                  {isExpanded && (
                    <div className="px-4 pb-5 pt-1 border-t border-[#222]/50 space-y-4 bg-[#111]/30 animate-fade-in text-xs">
                      
                      {/* Equipment/Difficulty details */}
                      <div className="grid grid-cols-2 gap-2 bg-[#1A1A1A] p-3 rounded-lg border border-[#222]">
                        <div>
                          <span className="text-[9px] uppercase tracking-wider text-gray-500">Equipamento</span>
                          <p className="font-bold text-white mt-0.5">{ex.equipment || 'Nenhum'}</p>
                        </div>
                        <div>
                          <span className="text-[9px] uppercase tracking-wider text-gray-500">Secundários</span>
                          <p className="font-bold text-gray-300 mt-0.5 truncate">{ex.secondaryMuscle || 'Nenhum'}</p>
                        </div>
                      </div>

                      {/* Instructions */}
                      {ex.instructions && ex.instructions.length > 0 && (
                        <div className="space-y-1.5">
                          <h4 className="font-black text-white uppercase tracking-wider flex items-center gap-1">
                            <Compass className="h-3.5 w-3.5 text-[#4F8CFF]" /> Passo a Passo
                          </h4>
                          <ol className="space-y-1.5">
                            {ex.instructions.map((step, idx) => (
                              <li key={idx} className="text-gray-300 leading-relaxed flex items-start space-x-1.5">
                                <span className="text-[#4F8CFF] font-mono font-bold">{idx + 1}.</span>
                                <span>{step}</span>
                              </li>
                            ))}
                          </ol>
                        </div>
                      )}

                      {/* Common Mistakes */}
                      {ex.commonMistakes && ex.commonMistakes.length > 0 && (
                        <div className="bg-red-950/10 border border-red-900/20 p-3 rounded-lg space-y-1">
                          <h4 className="font-black text-red-400 uppercase tracking-widest flex items-center gap-1">
                            <ShieldAlert className="h-3.5 w-3.5 text-red-400" /> Erros Comuns
                          </h4>
                          <ul className="space-y-1 list-disc pl-4 text-gray-300">
                            {ex.commonMistakes.map((m, idx) => (
                              <li key={idx}>{m}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Tips */}
                      {ex.tips && ex.tips.length > 0 && (
                        <div className="bg-blue-950/10 border border-blue-900/10 p-3 rounded-lg space-y-1">
                          <h4 className="font-black text-blue-400 uppercase tracking-widest flex items-center gap-1">
                            <Info className="h-3.5 w-3.5 text-blue-400" /> Dicas de Elite
                          </h4>
                          <ul className="space-y-1 list-disc pl-4 text-gray-300">
                            {ex.tips.map((t, idx) => (
                              <li key={idx}>{t}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Custom Simulated Exercise Movement Video/Animate Frame */}
                      <div className="bg-[#1A1A1A] p-3 rounded-lg border border-[#222] flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div className="w-2.5 h-2.5 bg-green-500 rounded-full animate-ping" />
                          <span className="text-[10px] text-gray-400 font-mono">SIMULADOR REPS EM LOOP</span>
                        </div>
                        <div className="flex space-x-1">
                          <div className="w-1.5 h-6 bg-[#4F8CFF] rounded-full animate-pulse [animation-delay:-0.4s]" />
                          <div className="w-1.5 h-8 bg-[#4F8CFF] rounded-full animate-pulse [animation-delay:-0.2s]" />
                          <div className="w-1.5 h-5 bg-[#4F8CFF] rounded-full animate-pulse" />
                        </div>
                      </div>

                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#141414] border-t border-[#222] flex">
          <button
            onClick={onClose}
            className="w-full py-3 bg-[#1A1A1A] hover:bg-[#222] text-gray-300 rounded-xl font-bold text-sm tracking-wide transition-colors border border-[#2c2c2c]"
          >
            Fechar Banco de Exercícios
          </button>
        </div>

      </div>
    </div>
  );
}
