import React, { useState, useEffect, useRef } from 'react';
import { X, Check, Flame, ChevronRight, HelpCircle, RefreshCw, Volume2, Info, Compass, ShieldAlert, Award } from 'lucide-react';
import { WorkoutExercise, Exercise, ExerciseLog, SetLog } from '../types';
import { exercisesDatabase } from '../data/exercises';
import { getProgressionSuggestion } from '../utils/progression';

interface ExerciseDetailModalProps {
  exercise: WorkoutExercise;
  history: ExerciseLog[];
  workoutId: string;
  onClose: () => void;
  onSaveLogs: (exerciseId: string, sets: SetLog[], notes: string) => void;
  onRestStart: (duration: number) => void;
}

export default function ExerciseDetailModal({
  exercise,
  history,
  workoutId,
  onClose,
  onSaveLogs,
  onRestStart,
}: ExerciseDetailModalProps) {
  // Find database info for extra details
  const dbInfo = exercisesDatabase.find((e) => e.id === exercise.exerciseId);

  // Load progression suggestion
  const progression = getProgressionSuggestion(exercise, history);

  // Load last log for this exercise
  const exLogs = history.filter((log) => log.exerciseId === exercise.exerciseId);
  const lastLog = exLogs.length > 0 ? exLogs[0] : null;

  // Initialize sets logs state
  const [sets, setSets] = useState<SetLog[]>(() => {
    const initialSets: SetLog[] = [];
    for (let i = 1; i <= exercise.setsCount; i++) {
      // Best guess for starting weight
      let startWeight = exercise.targetWeight || 10;
      if (progression.suggestedWeight) {
        startWeight = progression.suggestedWeight;
      } else if (lastLog && lastLog.sets.length >= i) {
        startWeight = lastLog.sets[i - 1].weight;
      } else if (lastLog && lastLog.sets.length > 0) {
        startWeight = lastLog.sets[0].weight;
      }

      // Best guess for reps
      let startReps = 10;
      const rangeParts = exercise.repsRange.split('-');
      if (rangeParts.length > 0) {
        startReps = parseInt(rangeParts[rangeParts.length - 1], 10) || 10;
      }

      initialSets.push({
        setNumber: i,
        weight: startWeight,
        reps: startReps,
        completed: false,
      });
    }
    return initialSets;
  });

  const [activeSetIndex, setActiveSetIndex] = useState(0);
  const [notes, setNotes] = useState(exercise.notes || '');
  const [activeTab, setActiveTab] = useState<'treino' | 'como_executar'>('treino');

  // Conclude a single set
  const handleToggleSet = (index: number) => {
    const updated = [...sets];
    const isNowCompleted = !updated[index].completed;
    updated[index].completed = isNowCompleted;
    setSets(updated);

    if (isNowCompleted) {
      // Auto trigger the rest timer
      onRestStart(exercise.restTime);
      
      // Auto move to the next set if available
      if (index < sets.length - 1) {
        setActiveSetIndex(index + 1);
      } else {
        // Completed all sets! Show feedback or let them review
      }
    }
  };

  const handleWeightChange = (index: number, val: string) => {
    const updated = [...sets];
    updated[index].weight = parseFloat(val) || 0;
    setSets(updated);
  };

  const handleRepsChange = (index: number, val: string) => {
    const updated = [...sets];
    updated[index].reps = parseInt(val, 10) || 0;
    setSets(updated);
  };

  const handleSaveAndClose = () => {
    onSaveLogs(exercise.id, sets, notes);
    onClose();
  };

  // Quick helper to fill all remaining sets with first set's values
  const handleCopyFirstSetValues = () => {
    if (sets.length === 0) return;
    const baseWeight = sets[0].weight;
    const baseReps = sets[0].reps;
    const updated = sets.map((s, idx) => {
      if (idx === 0) return s;
      return { ...s, weight: baseWeight, reps: baseReps };
    });
    setSets(updated);
  };

  const totalCompleted = sets.filter((s) => s.completed).length;
  const allDone = totalCompleted === sets.length;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-end justify-center p-0 sm:p-4 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#151515] w-full max-w-xl rounded-t-[32px] sm:rounded-[32px] border-t sm:border border-white/5 overflow-hidden flex flex-col max-h-[85vh] shadow-2xl relative">
        
        {/* Drag handle on mobile */}
        <div className="flex justify-center py-3 sm:hidden">
          <div className="w-12 h-1 bg-white/10 rounded-full" />
        </div>

        {/* Modal Header */}
        <div className="px-8 pt-4 sm:pt-8 pb-4 flex justify-between items-start">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="px-3 py-1 bg-[#4F8CFF]/10 text-[#4F8CFF] text-[10px] font-bold uppercase tracking-widest rounded-full border border-[#4F8CFF]/20">
                {exercise.primaryMuscle} {dbInfo?.secondaryMuscle ? `• ${dbInfo.secondaryMuscle}` : ''}
              </span>
            </div>
            <h2 className="text-3xl font-bold text-white tracking-tight">{exercise.name}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 bg-[#1A1A1A] hover:bg-[#252525] text-[#888] hover:text-white rounded-full transition-colors border border-transparent hover:border-[#2a2a2a]"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation Tabs (Treinar vs Como Executar) */}
        <div className="flex border-b border-white/5 px-8">
          <button
            onClick={() => setActiveTab('treino')}
            className={`mr-6 py-3 text-sm font-semibold tracking-wide border-b-2 transition-all ${
              activeTab === 'treino'
                ? 'border-[#4F8CFF] text-[#4F8CFF]'
                : 'border-transparent text-[#888] hover:text-[#bbb]'
            }`}
          >
            Registrar Série
          </button>
          <button
            onClick={() => setActiveTab('como_executar')}
            className={`py-3 text-sm font-semibold tracking-wide border-b-2 transition-all ${
              activeTab === 'como_executar'
                ? 'border-[#4F8CFF] text-[#4F8CFF]'
                : 'border-transparent text-[#888] hover:text-[#bbb]'
            }`}
          >
            Como Executar
          </button>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="overflow-y-auto px-8 py-6 space-y-6 flex-1 custom-scrollbar">
          
          {activeTab === 'treino' ? (
            <>
              {/* STATS COMPARISON GRID */}
              <div className="flex gap-8 border-b border-white/5 pb-6 mb-4">
                <div>
                  <p className="text-[#666] text-xs uppercase mb-1 tracking-widest font-bold">Última Carga</p>
                  <p className="text-xl font-semibold text-white">
                    {lastLog && lastLog.sets.length > 0 ? `${lastLog.sets[0].weight} kg` : '--'}
                  </p>
                </div>
                <div>
                  <p className="text-[#666] text-xs uppercase mb-1 tracking-widest font-bold">Meta</p>
                  <p className="text-xl font-semibold text-white">
                    {exercise.setsCount}x{exercise.repsRange}
                  </p>
                </div>
                {progression.action === 'increase' && (
                  <div>
                    <p className="text-[#666] text-xs uppercase mb-1 tracking-widest font-bold">Sugerido</p>
                    <p className="text-xl font-semibold text-white">
                      {progression.suggestedWeight} kg <span className="text-[#4F8CFF] text-sm">↑</span>
                    </p>
                  </div>
                )}
              </div>

              {/* LOGS TABLE */}
              <div className="space-y-4">
                <div className="grid grid-cols-4 gap-4 text-[#888] text-[10px] font-bold uppercase tracking-widest mb-2 px-2">
                  <div className="text-center">Série</div>
                  <div className="text-center">Carga (kg)</div>
                  <div className="text-center">Reps</div>
                  <div className="text-center">Ação</div>
                </div>

                <div className="space-y-3">
                  {sets.map((set, idx) => {
                    const isActive = idx === activeSetIndex;
                    return (
                      <div
                        key={set.setNumber}
                        className={`grid grid-cols-4 gap-4 items-center p-3 sm:p-4 rounded-2xl transition-all ${
                          set.completed
                            ? 'bg-[#1A1A1A]/40 opacity-50'
                            : isActive
                            ? 'bg-[#1A1A1A] border border-[#4F8CFF]/50 shadow-[0_0_10px_rgba(79,140,255,0.1)]'
                            : 'bg-[#1A1A1A] border border-white/5'
                        }`}
                      >
                        <div className="text-center text-xl font-bold text-[#888] font-mono">{set.setNumber}</div>
                        <div className="text-center">
                          <input
                            type="number"
                            step="0.5"
                            value={set.weight || ''}
                            onChange={(e) => handleWeightChange(idx, e.target.value)}
                            disabled={set.completed}
                            className="w-full bg-[#252525] border-none rounded-lg p-2 text-center text-white font-mono focus:ring-1 focus:ring-[#4F8CFF] disabled:opacity-50"
                          />
                        </div>
                        <div className="text-center">
                          <input
                            type="number"
                            value={set.reps || ''}
                            onChange={(e) => handleRepsChange(idx, e.target.value)}
                            disabled={set.completed}
                            className="w-full bg-[#252525] border-none rounded-lg p-2 text-center text-white font-mono focus:ring-1 focus:ring-[#4F8CFF] disabled:opacity-50"
                          />
                        </div>
                        <div className="flex justify-center">
                          <button
                            onClick={() => handleToggleSet(idx)}
                            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                              set.completed
                                ? 'bg-[#4F8CFF] text-white'
                                : 'border border-[#333] hover:border-[#4F8CFF] text-transparent hover:text-[#4F8CFF]'
                            }`}
                          >
                            <Check className="h-5 w-5" strokeWidth={3} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* EXERCISE NOTES */}
              <div className="space-y-1.5 pt-4 border-t border-white/5">
                <label className="text-[10px] font-bold text-[#888] uppercase tracking-widest block">
                  Anotações
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ex: Pegada supinada, focar no cotovelo..."
                  rows={2}
                  className="w-full bg-[#1A1A1A] border border-white/5 rounded-xl p-3 text-sm text-[#bbb] placeholder-[#555] focus:outline-none focus:border-[#4F8CFF] resize-none"
                />
              </div>
            </>
          ) : (
            /* COMO EXECUTAR INSTRUCTION TAB */
            <div className="space-y-5 animate-fade-in">
              {dbInfo?.instructions && dbInfo.instructions.length > 0 ? (
                <div className="space-y-3">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Compass className="h-4 w-4 text-[#4F8CFF]" /> Passo a Passo
                  </h3>
                  <ol className="space-y-2.5">
                    {dbInfo.instructions.map((step, sIdx) => (
                      <li key={sIdx} className="text-xs text-gray-300 leading-relaxed flex items-start space-x-2">
                        <span className="font-mono font-bold text-[#4F8CFF] bg-[#1C2638] px-1.5 rounded text-[10px] mt-0.5">{sIdx + 1}</span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              ) : (
                <p className="text-xs text-gray-500">Nenhum tutorial registrado para este exercício.</p>
              )}

              {dbInfo?.commonMistakes && dbInfo.commonMistakes.length > 0 && (
                <div className="bg-red-950/10 border border-red-900/30 p-4 rounded-xl space-y-2">
                  <h3 className="text-xs font-black text-red-400 uppercase tracking-widest flex items-center gap-1.5">
                    <ShieldAlert className="h-4 w-4 text-red-400" /> Erros Comuns a Evitar
                  </h3>
                  <ul className="space-y-1.5 list-disc pl-4">
                    {dbInfo.commonMistakes.map((mistake, mIdx) => (
                      <li key={mIdx} className="text-xs text-gray-300 leading-relaxed">
                        {mistake}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {dbInfo?.tips && dbInfo.tips.length > 0 && (
                <div className="bg-blue-950/10 border border-blue-900/20 p-4 rounded-xl space-y-2">
                  <h3 className="text-xs font-black text-blue-400 uppercase tracking-widest flex items-center gap-1.5">
                    <Info className="h-4 w-4 text-blue-400" /> Dicas de Execução de Elite
                  </h3>
                  <ul className="space-y-1.5 list-disc pl-4">
                    {dbInfo.tips.map((tip, tIdx) => (
                      <li key={tIdx} className="text-xs text-gray-300 leading-relaxed">
                        {tip}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Action Buttons - Moved inside scrollable area */}
          <div className="pt-6 flex gap-3 sm:gap-4 border-t border-white/5 mt-4">
            <button
              onClick={onClose}
              className="flex-1 py-3.5 bg-[#1A1A1A] hover:bg-[#252525] text-white rounded-full font-semibold text-sm border border-[#2a2a2a] transition-all"
            >
              Voltar
            </button>
            
            <button
              onClick={handleSaveAndClose}
              className={`flex-[1.5] py-3.5 rounded-full font-semibold text-sm transition-all flex items-center justify-center gap-2 ${
                allDone
                  ? 'bg-[#4F8CFF] hover:bg-[#3c7ee6] text-white shadow-[0_4px_15px_rgba(79,140,255,0.3)]'
                  : 'bg-[#4F8CFF] hover:bg-[#3c7ee6] text-white'
              }`}
            >
              <Check className="h-5 w-5 stroke-[3]" />
              {allDone ? 'Concluir' : 'Salvar'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
