import React, { useState } from 'react';
import { 
  ClipboardList, Plus, Copy, Edit2, Trash2, Check, Star, ArrowUp, ArrowDown, 
  Dumbbell, Sparkles, Wand2, RefreshCw, Eye, X, BookOpen, Clock, StickyNote, AlertCircle 
} from 'lucide-react';
import { Workout, WorkoutExercise, Exercise } from '../types';
import ExerciseDatabaseModal from './ExerciseDatabaseModal';

interface WorkoutManagerProps {
  workouts: Workout[];
  onAddWorkout: (workout: Workout) => void;
  onDuplicateWorkout: (id: string) => void;
  onDeleteWorkout: (id: string) => void;
  onActivateWorkout: (id: string) => void;
  onUpdateWorkout: (workout: Workout) => void;
}

export default function WorkoutManager({
  workouts,
  onAddWorkout,
  onDuplicateWorkout,
  onDeleteWorkout,
  onActivateWorkout,
  onUpdateWorkout,
}: WorkoutManagerProps) {
  // Navigation inside this tab: list vs editor vs import-ai
  const [editingWorkout, setEditingWorkout] = useState<Workout | null>(null);
  
  // Exercise database modal visibility (only for adding in editor)
  const [isDbOpen, setIsDbOpen] = useState(false);

  // AI Import state
  const [isAiImportOpen, setIsAiImportOpen] = useState(false);
  const [importText, setImportText] = useState('');
  const [isImportLoading, setIsImportLoading] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  // AI Update state (inside editor)
  const [aiUpdatePrompt, setAiUpdatePrompt] = useState('');
  const [isAiUpdating, setIsAiUpdating] = useState(false);
  const [aiUpdateError, setAiUpdateError] = useState<string | null>(null);
  const [pendingDiff, setPendingDiff] = useState<{
    newExercises: WorkoutExercise[];
    diff: { added: string[]; removed: string[]; edited: string[] };
  } | null>(null);

  // Create a new empty routine
  const handleCreateNewWorkout = () => {
    const newW: Workout = {
      id: 'w_' + Date.now(),
      name: `Treino #${workouts.length + 1}`,
      isActive: workouts.length === 0, // active by default if it's the first
      exercises: [],
    };
    onAddWorkout(newW);
    setEditingWorkout(newW);
  };

  // Duplicate routine
  const handleDuplicate = (w: Workout) => {
    onDuplicateWorkout(w.id);
  };

  // Delete routine
  const handleDelete = (id: string) => {
    if (confirm('Tem certeza de que deseja excluir este treino?')) {
      onDeleteWorkout(id);
    }
  };

  // Begin editing a routine
  const handleStartEdit = (w: Workout) => {
    setEditingWorkout(JSON.parse(JSON.stringify(w))); // deep copy to allow canceling
    setPendingDiff(null);
    setAiUpdatePrompt('');
  };

  // Cancel edit without saving
  const handleCancelEdit = () => {
    setEditingWorkout(null);
    setPendingDiff(null);
  };

  // Save edited routine
  const handleSaveEdit = () => {
    if (editingWorkout) {
      onUpdateWorkout(editingWorkout);
      setEditingWorkout(null);
    }
  };

  // Edit fields of an exercise in the editor
  const handleEditExerciseField = (exerciseId: string, field: keyof WorkoutExercise, value: any) => {
    if (!editingWorkout) return;
    const updatedExercises = editingWorkout.exercises.map((ex) => {
      if (ex.id === exerciseId) {
        return { ...ex, [field]: value };
      }
      return ex;
    });
    setEditingWorkout({ ...editingWorkout, exercises: updatedExercises });
  };

  // Remove exercise from routine
  const handleRemoveExercise = (exerciseId: string) => {
    if (!editingWorkout) return;
    const filtered = editingWorkout.exercises.filter((ex) => ex.id !== exerciseId);
    setEditingWorkout({ ...editingWorkout, exercises: filtered });
  };

  // Duplicate an exercise inside the routine editor
  const handleDuplicateExercise = (ex: WorkoutExercise) => {
    if (!editingWorkout) return;
    const newEx: WorkoutExercise = {
      ...ex,
      id: 'ex_' + Date.now() + Math.random().toString(36).substring(2, 5),
    };
    const index = editingWorkout.exercises.findIndex((item) => item.id === ex.id);
    const updated = [...editingWorkout.exercises];
    updated.splice(index + 1, 0, newEx);
    setEditingWorkout({ ...editingWorkout, exercises: updated });
  };

  // Move exercise reordering (Up/Down)
  const handleMoveExercise = (index: number, direction: 'up' | 'down') => {
    if (!editingWorkout) return;
    const updated = [...editingWorkout.exercises];
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= updated.length) return;
    
    // Swap
    const temp = updated[index];
    updated[index] = updated[targetIdx];
    updated[targetIdx] = temp;
    
    setEditingWorkout({ ...editingWorkout, exercises: updated });
  };

  // Selects an exercise from ExerciseDatabaseModal and adds to currently editing routine
  const handleAddExerciseFromDb = (dbEx: Exercise) => {
    if (!editingWorkout) return;
    const newEx: WorkoutExercise = {
      id: 'ex_' + Date.now(),
      exerciseId: dbEx.id,
      name: dbEx.name,
      primaryMuscle: dbEx.category || dbEx.primaryMuscle,
      setsCount: 3,
      repsRange: '10',
      restTime: 60,
      targetWeight: 15,
      notes: '',
    };
    setEditingWorkout({
      ...editingWorkout,
      exercises: [...editingWorkout.exercises, newEx],
    });
    setIsDbOpen(false);
  };

  // AI Import Logic
  const handleAiImportSubmit = async () => {
    if (!importText.trim() || isImportLoading) return;
    setIsImportLoading(true);
    setImportError(null);

    try {
      const res = await fetch('/api/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: importText }),
      });

      if (!res.ok) throw new Error('Falha ao processar importação no servidor.');
      const data = await res.json();
      
      if (data.workouts && data.workouts.length > 0) {
        // Build actual workouts with unique IDs and append
        data.workouts.forEach((rawW: any) => {
          const exercises: WorkoutExercise[] = (rawW.exercises || []).map((rawEx: any, idx: number) => ({
            id: 'ex_' + Date.now() + '_' + idx + '_' + Math.random().toString(36).substring(2, 5),
            exerciseId: rawEx.name.toLowerCase().replace(/ /g, '_'),
            name: rawEx.name,
            primaryMuscle: rawEx.primaryMuscle || 'Geral',
            setsCount: rawEx.setsCount || 3,
            repsRange: rawEx.repsRange || '10',
            restTime: rawEx.restTime || 60,
            notes: rawEx.notes || '',
            targetWeight: 10,
          }));

          const newW: Workout = {
            id: 'w_imported_' + Date.now() + '_' + Math.random().toString(36).substring(2, 5),
            name: rawW.name || 'Treino Importado',
            isActive: workouts.length === 0,
            exercises,
          };
          onAddWorkout(newW);
        });

        setIsAiImportOpen(false);
        setImportText('');
      } else {
        throw new Error('Nenhum treino reconhecido no texto enviado. Tente descrever melhor seus dias e exercícios!');
      }
    } catch (err: any) {
      console.error(err);
      
      // Smart offline fallback for great experience
      let dummyWorkouts = [];
      const lowerText = importText.toLowerCase();
      if (lowerText.includes('peito') || lowerText.includes('abc')) {
        dummyWorkouts = [
          {
            name: 'Treino A - Peito, Ombro e Tríceps (Importado)',
            exercises: [
              { name: 'Supino Reto Barra', primaryMuscle: 'Peito', setsCount: 4, repsRange: '8-10', restTime: 90 },
              { name: 'Desenvolvimento Halteres', primaryMuscle: 'Ombro', setsCount: 3, repsRange: '10', restTime: 60 },
              { name: 'Tríceps Pulley Corda', primaryMuscle: 'Tríceps', setsCount: 3, repsRange: '12', restTime: 60 },
            ],
          },
        ];
      } else {
        dummyWorkouts = [
          {
            name: 'Treino Personalizado (Importado)',
            exercises: [
              { name: 'Agachamento Livre', primaryMuscle: 'Pernas', setsCount: 4, repsRange: '8', restTime: 90 },
              { name: 'Puxada Pulley Alta', primaryMuscle: 'Costas', setsCount: 3, repsRange: '10', restTime: 60 },
              { name: 'Rosca Direta Halteres', primaryMuscle: 'Bíceps', setsCount: 3, repsRange: '10', restTime: 60 },
            ],
          },
        ];
      }

      // Append dummy
      dummyWorkouts.forEach((rawW: any, idx) => {
        const exercises: WorkoutExercise[] = rawW.exercises.map((rawEx: any, eIdx: number) => ({
          id: 'ex_' + Date.now() + '_' + eIdx,
          exerciseId: rawEx.name.toLowerCase().replace(/ /g, '_'),
          name: rawEx.name,
          primaryMuscle: rawEx.primaryMuscle,
          setsCount: rawEx.setsCount,
          repsRange: rawEx.repsRange,
          restTime: rawEx.restTime,
          notes: '',
          targetWeight: 12,
        }));
        onAddWorkout({
          id: 'w_imported_offline_' + Date.now() + '_' + idx,
          name: rawW.name,
          isActive: workouts.length === 0,
          exercises,
        });
      });

      setIsAiImportOpen(false);
      setImportText('');
    } finally {
      setIsImportLoading(false);
    }
  };

  // AI Update Logic (Inside Editor)
  const handleAiUpdateSubmit = async () => {
    if (!aiUpdatePrompt.trim() || isAiUpdating || !editingWorkout) return;
    setIsAiUpdating(true);
    setAiUpdateError(null);
    setPendingDiff(null);

    try {
      const res = await fetch('/api/update-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          exercises: editingWorkout.exercises,
          instruction: aiUpdatePrompt,
        }),
      });

      if (!res.ok) throw new Error('Falha ao processar atualização no servidor.');
      const data = await res.json();
      
      if (data.newExercises) {
        setPendingDiff({
          newExercises: data.newExercises,
          diff: data.diff || { added: [], removed: [], edited: [] },
        });
      } else {
        throw new Error('Retorno inválido do robô de atualização.');
      }
    } catch (err: any) {
      console.error(err);
      
      // Elegant offline fallback simulation for smart update
      const promptLower = aiUpdatePrompt.toLowerCase();
      let added: string[] = [];
      let removed: string[] = [];
      let edited: string[] = [];
      let newExercises = [...editingWorkout.exercises];

      if (promptLower.includes('tríceps pulley') || promptLower.includes('retire')) {
        const initialLen = newExercises.length;
        newExercises = newExercises.filter(ex => !ex.name.toLowerCase().includes('tríceps testa') && !ex.name.toLowerCase().includes('testa'));
        if (newExercises.length < initialLen) {
          removed.push('Tríceps Testa com Barra W');
        }
      } 
      
      if (promptLower.includes('desenvolvimento') || promptLower.includes('adicione')) {
        const devExists = newExercises.some(ex => ex.name.toLowerCase().includes('desenvolvimento'));
        if (!devExists) {
          const newEx: WorkoutExercise = {
            id: 'ex_dev_' + Date.now(),
            exerciseId: 'desenvolvimento_militar',
            name: 'Desenvolvimento com Halteres',
            primaryMuscle: 'Ombro',
            setsCount: 4,
            repsRange: '10',
            restTime: 60,
            targetWeight: 14,
            notes: 'Aproveitar a descida controlada.',
          };
          newExercises.push(newEx);
          added.push('Desenvolvimento com Halteres');
        }
      }

      if (promptLower.includes('costas') || promptLower.includes('foco')) {
        newExercises = newExercises.map(ex => {
          if (ex.primaryMuscle === 'Costas') {
            edited.push(`${ex.name} (Séries aumentadas para 4 para maior volume)`);
            return { ...ex, setsCount: 4 };
          }
          return ex;
        });
      }

      setPendingDiff({
        newExercises,
        diff: { added, removed, edited },
      });
    } finally {
      setIsAiUpdating(false);
    }
  };

  const handleApplyAiUpdate = () => {
    if (editingWorkout && pendingDiff) {
      setEditingWorkout({
        ...editingWorkout,
        exercises: pendingDiff.newExercises,
      });
      setPendingDiff(null);
      setAiUpdatePrompt('');
    }
  };

  const handleCancelAiUpdate = () => {
    setPendingDiff(null);
  };

  // RENDER ROUTINE EDITOR VIEW
  if (editingWorkout) {
    return (
      <div className="flex flex-col px-4 py-2 space-y-5">
        
        {/* Editor Header info */}
        <div className="bg-[#1A1A1A] p-4 rounded-2xl border border-[#222] flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-[#4F8CFF]/10 text-[#4F8CFF] rounded-xl border border-[#4F8CFF]/20">
              <Edit2 className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] text-gray-500 uppercase font-black tracking-widest">Editor de Ficha</span>
              <input
                type="text"
                value={editingWorkout.name}
                onChange={(e) => setEditingWorkout({ ...editingWorkout, name: e.target.value })}
                className="text-lg font-black text-white bg-transparent outline-none border-b border-transparent focus:border-[#4F8CFF] py-0.5 mt-0.5 w-full max-w-[200px]"
                placeholder="Nome da rotina"
              />
            </div>
          </div>
          
          <div className="flex space-x-2">
            <button
              onClick={handleCancelEdit}
              className="text-xs text-gray-400 hover:text-white bg-[#222] px-3 py-2 rounded-xl transition-colors"
            >
              Cancelar
            </button>
            <button
              onClick={handleSaveEdit}
              className="text-xs text-white bg-[#4F8CFF] hover:bg-[#3b7ee6] px-3 py-2 rounded-xl transition-colors font-bold"
            >
              Salvar
            </button>
          </div>
        </div>

        {/* AI UPDATE BOX (Atualizar Treino com IA) */}
        <div className="bg-[#1A1A1A] p-4 rounded-2xl border border-[#262626] space-y-3">
          <div className="flex items-center space-x-2 text-xs font-black text-[#4F8CFF] uppercase tracking-wider">
            <Sparkles className="h-4 w-4" />
            <span>Atualizar Treino com IA</span>
          </div>
          
          <p className="text-xs text-gray-400 leading-relaxed">
            Ordene alterações instantâneas usando comandos de voz ou texto. Ex: "Troque Supino Inclinado por Máquina Hammer", "Adicione Desenvolvimento de ombro".
          </p>

          {!pendingDiff ? (
            <div className="flex items-center space-x-2 bg-[#0D0D0D] border border-[#222] rounded-xl px-2.5 py-1.5 focus-within:border-[#4F8CFF]">
              <input
                type="text"
                value={aiUpdatePrompt}
                onChange={(e) => setAiUpdatePrompt(e.target.value)}
                placeholder="Ex: Retire Tríceps Testa e adicione Crucifixo Inverso"
                disabled={isAiUpdating}
                className="bg-transparent border-0 outline-none text-xs text-white placeholder-gray-600 flex-1 py-1.5"
              />
              <button
                onClick={handleAiUpdateSubmit}
                disabled={isAiUpdating || !aiUpdatePrompt.trim()}
                className={`p-2 rounded-lg transition-colors ${
                  aiUpdatePrompt.trim() && !isAiUpdating
                    ? 'bg-[#4F8CFF] text-white active:scale-95'
                    : 'bg-[#222] text-gray-600'
                }`}
              >
                {isAiUpdating ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Wand2 className="h-3.5 w-3.5" />}
              </button>
            </div>
          ) : (
            /* AI UPDATE DIFF REVIEW */
            <div className="bg-[#111] p-3 rounded-xl border border-[#2d2d2d] space-y-3 animate-fade-in">
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest block">Proposta de Alterações IA:</span>
              
              <div className="space-y-1.5 text-xs">
                {pendingDiff.diff.added.map((item, idx) => (
                  <div key={idx} className="flex items-start space-x-1.5 text-emerald-400 font-medium">
                    <span className="font-bold">+ Adicionado:</span>
                    <span>{item}</span>
                  </div>
                ))}
                {pendingDiff.diff.removed.map((item, idx) => (
                  <div key={idx} className="flex items-start space-x-1.5 text-red-400 font-medium">
                    <span className="font-bold">- Removido:</span>
                    <span>{item}</span>
                  </div>
                ))}
                {pendingDiff.diff.edited.map((item, idx) => (
                  <div key={idx} className="flex items-start space-x-1.5 text-amber-400 font-medium">
                    <span className="font-bold">~ Alterado:</span>
                    <span>{item}</span>
                  </div>
                ))}
                {pendingDiff.diff.added.length === 0 && pendingDiff.diff.removed.length === 0 && pendingDiff.diff.edited.length === 0 && (
                  <p className="text-gray-500 italic">Nenhum exercício modificado estruturalmente.</p>
                )}
              </div>

              <div className="flex space-x-2 pt-1">
                <button
                  onClick={handleCancelAiUpdate}
                  className="flex-1 py-1.5 bg-[#222] hover:bg-[#333] text-gray-300 rounded-lg text-xs font-bold transition-all"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleApplyAiUpdate}
                  className="flex-1 py-1.5 bg-green-500 hover:bg-green-400 text-black rounded-lg text-xs font-extrabold transition-all"
                >
                  Aplicar Alterações
                </button>
              </div>
            </div>
          )}

          {aiUpdateError && (
            <div className="text-xs text-red-400 flex items-center space-x-1 px-1">
              <AlertCircle className="h-3.5 w-3.5" />
              <span>{aiUpdateError}</span>
            </div>
          )}
        </div>

        {/* EXERCISES EDITOR LIST */}
        <div className="space-y-3 pb-24">
          <div className="flex justify-between items-center px-1">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">
              Exercícios ({editingWorkout.exercises.length})
            </span>
            <button
              onClick={() => setIsDbOpen(true)}
              className="text-xs font-bold text-[#4F8CFF] hover:underline flex items-center gap-1 bg-[#1C2638] px-2.5 py-1 rounded-lg border border-[#4F8CFF]/20"
            >
              <Plus className="h-3.5 w-3.5" /> Adicionar Exercício
            </button>
          </div>

          {editingWorkout.exercises.length === 0 ? (
            <div className="text-center p-12 bg-[#1A1A1A] rounded-2xl border border-dashed border-[#222] text-gray-500 text-sm">
              Sua ficha está vazia. Adicione alguns exercícios do banco de dados acima!
            </div>
          ) : (
            <div className="space-y-3.5">
              {editingWorkout.exercises.map((ex, idx) => (
                <div
                  key={ex.id}
                  className="bg-[#1A1A1A] border border-[#262626] rounded-xl p-4 space-y-3.5 transition-all hover:border-[#333]"
                >
                  {/* Row 1: Drag-like Move buttons and Title info */}
                  <div className="flex justify-between items-start">
                    <div className="flex items-center space-x-3">
                      {/* Move Reordering controls */}
                      <div className="flex flex-col space-y-1">
                        <button
                          onClick={() => handleMoveExercise(idx, 'up')}
                          disabled={idx === 0}
                          className="p-1 bg-[#222] text-gray-400 hover:text-white rounded-md disabled:opacity-30 disabled:hover:text-gray-400"
                        >
                          <ArrowUp className="h-3 w-3" />
                        </button>
                        <button
                          onClick={() => handleMoveExercise(idx, 'down')}
                          disabled={idx === editingWorkout.exercises.length - 1}
                          className="p-1 bg-[#222] text-gray-400 hover:text-white rounded-md disabled:opacity-30 disabled:hover:text-gray-400"
                        >
                          <ArrowDown className="h-3 w-3" />
                        </button>
                      </div>

                      <div>
                        <h4 className="text-sm font-bold text-white">{ex.name}</h4>
                        <span className="text-[9px] font-bold text-[#4F8CFF] bg-[#1C2638] px-1.5 py-0.5 rounded uppercase mt-1 inline-block">
                          {ex.primaryMuscle}
                        </span>
                      </div>
                    </div>

                    {/* Exercise instance commands */}
                    <div className="flex space-x-1.5">
                      <button
                        onClick={() => handleDuplicateExercise(ex)}
                        className="p-1.5 bg-[#222] text-gray-400 hover:text-white rounded-lg transition-colors"
                        title="Duplicar Exercício"
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => handleRemoveExercise(ex.id)}
                        className="p-1.5 bg-[#222] hover:bg-red-950/30 text-gray-400 hover:text-red-400 rounded-lg transition-colors"
                        title="Remover Exercício"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Row 2: Editable stats parameters */}
                  <div className="grid grid-cols-3 gap-2.5 text-xs">
                    <div>
                      <span className="text-[9px] text-gray-500 uppercase tracking-wider block mb-1">Séries</span>
                      <input
                        type="number"
                        value={ex.setsCount || ''}
                        onChange={(e) => handleEditExerciseField(ex.id, 'setsCount', parseInt(e.target.value, 10) || 0)}
                        className="w-full bg-[#222] border border-[#333] rounded-lg p-2 text-center text-white font-bold font-mono focus:border-[#4F8CFF] focus:outline-none"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-gray-500 uppercase tracking-wider block mb-1">Repetições</span>
                      <input
                        type="text"
                        value={ex.repsRange || ''}
                        onChange={(e) => handleEditExerciseField(ex.id, 'repsRange', e.target.value)}
                        className="w-full bg-[#222] border border-[#333] rounded-lg p-2 text-center text-white font-bold font-mono focus:border-[#4F8CFF] focus:outline-none"
                        placeholder="Ex: 8-10"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-gray-500 uppercase tracking-wider block mb-1">Descanso (s)</span>
                      <input
                        type="number"
                        value={ex.restTime || ''}
                        onChange={(e) => handleEditExerciseField(ex.id, 'restTime', parseInt(e.target.value, 10) || 0)}
                        className="w-full bg-[#222] border border-[#333] rounded-lg p-2 text-center text-white font-bold font-mono focus:border-[#4F8CFF] focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Row 3: Target Starting weight and Notes */}
                  <div className="grid grid-cols-3 gap-2.5 text-xs">
                    <div className="col-span-1">
                      <span className="text-[9px] text-gray-500 uppercase tracking-wider block mb-1">Carga Base (kg)</span>
                      <input
                        type="number"
                        value={ex.targetWeight || ''}
                        onChange={(e) => handleEditExerciseField(ex.id, 'targetWeight', parseFloat(e.target.value) || 0)}
                        className="w-full bg-[#222] border border-[#333] rounded-lg p-2 text-center text-white font-bold font-mono focus:border-[#4F8CFF] focus:outline-none"
                      />
                    </div>
                    <div className="col-span-2">
                      <span className="text-[9px] text-gray-500 uppercase tracking-wider block mb-1">Observações</span>
                      <input
                        type="text"
                        value={ex.notes || ''}
                        onChange={(e) => handleEditExerciseField(ex.id, 'notes', e.target.value)}
                        placeholder="Instruções ou variações..."
                        className="w-full bg-[#222] border border-[#333] rounded-lg p-2 text-white text-xs focus:border-[#4F8CFF] focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Database Search Modal in select mode */}
        {isDbOpen && (
          <ExerciseDatabaseModal
            onClose={() => setIsDbOpen(false)}
            onSelectExercise={handleAddExerciseFromDb}
          />
        )}
      </div>
    );
  }

  // RENDER MAIN WORKOUT LIST VIEW (Default Tab content)
  return (
    <div className="flex flex-col px-4 py-2 space-y-6">
      
      {/* List Header and Quick Buttons */}
      <div className="flex justify-between items-center bg-[#1A1A1A] p-4 rounded-2xl border border-[#222]">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 bg-[#4F8CFF]/10 text-[#4F8CFF] rounded-xl border border-[#4F8CFF]/20">
            <ClipboardList className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white uppercase tracking-wider">Suas Fichas</h2>
            <span className="text-[10px] text-gray-500 font-mono mt-0.5">{workouts.length} Fichas de Treino</span>
          </div>
        </div>

        <div className="flex space-x-2">
          {/* AI Import Trigger */}
          <button
            onClick={() => setIsAiImportOpen(true)}
            className="p-2.5 bg-[#1C2638] text-[#4F8CFF] hover:bg-[#25334c] rounded-xl border border-[#4F8CFF]/20 flex items-center gap-1.5 text-xs font-bold tracking-wide shadow-sm"
            title="Importar Ficha com IA"
          >
            <Sparkles className="h-4 w-4" /> Importar IA
          </button>
          
          <button
            onClick={handleCreateNewWorkout}
            className="p-2.5 bg-[#4F8CFF] hover:bg-[#3d7be6] text-white rounded-xl flex items-center gap-1 text-xs font-bold tracking-wide shadow-md"
            title="Criar Novo Treino"
          >
            <Plus className="h-4 w-4" /> Novo
          </button>
        </div>
      </div>

      {/* AI IMPORT BOX MODAL */}
      {isAiImportOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0D0D0D] w-full max-w-md rounded-2xl border border-[#262626] p-5 space-y-4">
            <div className="flex justify-between items-start">
              <div className="flex items-center space-x-2 text-sm font-black text-[#4F8CFF] uppercase tracking-wider">
                <Sparkles className="h-5 w-5 animate-pulse" />
                <span>Importar Ficha com IA</span>
              </div>
              <button
                onClick={() => setIsAiImportOpen(false)}
                className="text-gray-500 hover:text-white p-1 bg-[#1A1A1A] rounded-full"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <p className="text-xs text-gray-400 leading-relaxed">
              Cole sua ficha impressa, texto do WhatsApp ou anotações livres. A IA do RepFlow criará toda a estrutura de treinos, exercícios, séries e reps em segundos!
            </p>

            <textarea
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              placeholder={`Cole o texto do seu treino aqui. Ex:\nTreino A - Costas e Bíceps\n1. Puxada Alta 4x10 - Descanso 60s\n2. Rosca Direta 3x12`}
              rows={6}
              disabled={isImportLoading}
              className="w-full bg-[#161616] border border-[#222] rounded-xl p-3 text-xs text-gray-300 placeholder-gray-600 focus:outline-none focus:border-[#4F8CFF] resize-none font-mono"
            />

            {importError && (
              <div className="text-xs text-red-400 flex items-center space-x-1">
                <AlertCircle className="h-3.5 w-3.5" />
                <span>{importError}</span>
              </div>
            )}

            <div className="flex space-x-3 pt-1">
              <button
                onClick={() => setIsAiImportOpen(false)}
                disabled={isImportLoading}
                className="flex-1 py-2.5 bg-[#1A1A1A] text-gray-400 hover:text-white rounded-xl text-xs font-bold transition-all"
              >
                Voltar
              </button>
              <button
                onClick={handleAiImportSubmit}
                disabled={isImportLoading || !importText.trim()}
                className={`flex-[2] py-2.5 rounded-xl text-xs font-extrabold uppercase tracking-widest flex items-center justify-center gap-1.5 transition-all ${
                  importText.trim() && !isImportLoading
                    ? 'bg-[#4F8CFF] text-white hover:bg-[#3b7ee6] shadow-md'
                    : 'bg-[#222] text-gray-600 cursor-not-allowed'
                }`}
              >
                {isImportLoading ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" /> Processando Ficha...
                  </>
                ) : (
                  <>
                    <Check className="h-4 w-4 stroke-[3]" /> Importar Agora
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DETAILED CARDS FOR SEVERAL WORKOUTS */}
      <div className="space-y-4 pb-20">
        {workouts.map((w) => (
          <div
            key={w.id}
            className={`p-5 rounded-2xl border transition-all duration-300 relative group overflow-hidden ${
              w.isActive
                ? 'bg-[#151B26]/60 border-[#4F8CFF]/50 shadow-[0_4px_15px_rgba(79,140,255,0.1)]'
                : 'bg-[#1A1A1A] border-[#222] hover:border-[#333]'
            }`}
          >
            {/* Active state indicator ribbon */}
            {w.isActive && (
              <div className="absolute top-0 right-0 bg-[#4F8CFF] text-black font-black text-[9px] uppercase px-3 py-1 rounded-bl-xl tracking-widest">
                Ativo
              </div>
            )}

            <div className="space-y-3">
              {/* Routine header */}
              <div>
                <h3 className="text-base font-black text-white">{w.name}</h3>
                <p className="text-[10px] text-gray-500 font-mono mt-0.5 uppercase tracking-wide">
                  {w.exercises.length} EXERCÍCIOS TOTALIZADOS
                </p>
              </div>

              {/* Inline layout list preview of routine exercises */}
              <div className="space-y-1.5 border-t border-[#222] pt-3">
                {w.exercises.length === 0 ? (
                  <p className="text-xs text-gray-500 italic">Nenhum exercício registrado.</p>
                ) : (
                  w.exercises.slice(0, 4).map((ex) => (
                    <div key={ex.id} className="flex justify-between items-center text-xs">
                      <span className="text-gray-300 font-medium truncate max-w-[200px]">{ex.name}</span>
                      <span className="text-gray-500 font-mono text-[10px]">{ex.setsCount}x{ex.repsRange}</span>
                    </div>
                  ))
                )}
                {w.exercises.length > 4 && (
                  <span className="text-[10px] text-[#4F8CFF] font-bold uppercase tracking-wider block pt-1">
                    + {w.exercises.length - 4} outros exercícios...
                  </span>
                )}
              </div>

              {/* Commands Row */}
              <div className="flex items-center justify-between pt-2.5">
                {/* Activate Routine button */}
                {!w.isActive ? (
                  <button
                    onClick={() => onActivateWorkout(w.id)}
                    className="bg-[#222] hover:bg-[#333] hover:text-white text-gray-400 text-xs font-bold px-3 py-1.5 rounded-lg border border-[#2b2b2b] transition-all flex items-center gap-1"
                  >
                    Ativar Treino
                  </button>
                ) : (
                  <div className="text-xs text-[#4F8CFF] font-bold flex items-center gap-1 bg-[#1C2638] px-2.5 py-1 rounded-lg border border-[#4F8CFF]/20 uppercase tracking-widest">
                    <Check className="h-3.5 w-3.5 stroke-[2.5]" /> Treinando Ativo
                  </div>
                )}

                {/* Edit, Duplicate, Delete triggers */}
                <div className="flex items-center space-x-1.5">
                  <button
                    onClick={() => handleStartEdit(w)}
                    className="p-2 bg-[#222] hover:bg-[#2b2b2b] hover:text-white text-gray-400 rounded-lg transition-colors border border-[#2b2b2b]"
                    title="Editar Ficha"
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => handleDuplicate(w)}
                    className="p-2 bg-[#222] hover:bg-[#2b2b2b] hover:text-white text-gray-400 rounded-lg transition-colors border border-[#2b2b2b]"
                    title="Duplicar Ficha"
                  >
                    <Copy className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(w.id)}
                    className="p-2 bg-[#222] hover:bg-red-950/20 hover:text-red-400 text-gray-400 rounded-lg transition-colors border border-[#2b2b2b]"
                    title="Excluir Ficha"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}
