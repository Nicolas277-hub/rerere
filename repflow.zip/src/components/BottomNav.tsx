import React from 'react';
import { Dumbbell, Bot, ClipboardList, Settings } from 'lucide-react';

interface BottomNavProps {
  activeTab: 'treino' | 'coach' | 'treinos' | 'config';
  onTabChange: (tab: 'treino' | 'coach' | 'treinos' | 'config') => void;
}

export default function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const tabs = [
    { id: 'treino' as const, label: 'Treino', icon: Dumbbell },
    { id: 'coach' as const, label: 'Coach IA', icon: Bot },
    { id: 'treinos' as const, label: 'Treinos', icon: ClipboardList },
    { id: 'config' as const, label: 'Config', icon: Settings },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 h-20 bg-[#0D0D0D] border-t border-[#1A1A1A] flex items-center justify-around px-4 sm:px-12 max-w-xl mx-auto shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            id={`nav-btn-${tab.id}`}
            onClick={() => onTabChange(tab.id)}
            className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
              isActive ? 'text-[#4F8CFF]' : 'text-[#444] hover:text-[#888]'
            }`}
          >
            <Icon className="h-6 w-6" strokeWidth={isActive ? 2.5 : 2} />
            <span className="text-[10px] font-bold uppercase tracking-widest">
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
