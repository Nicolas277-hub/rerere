import React, { useState, useEffect, useRef } from 'react';
import { Bot, Send, User, Sparkles, AlertCircle, Dumbbell, Zap, HelpCircle } from 'lucide-react';
import { Workout, ExerciseLog } from '../types';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface CoachIAProps {
  workouts: Workout[];
  history: ExerciseLog[];
}

export default function CoachIA({ workouts, history }: CoachIAProps) {
  const [messages, setMessages] = useState<Message[]>(() => {
    return [
      {
        role: 'assistant',
        content: `Olá, atleta! Eu sou seu **Coach IA** do RepFlow. 💪

Estou ciente de toda a sua rotina de treinamento e histórico recente de cargas. Meu único objetivo é te ajudar a progredir da forma mais rápida, segura e eficiente possível.

Como posso te ajudar hoje? Sinta-se à vontade para me fazer perguntas ou usar um dos atalhos rápidos abaixo!`,
      },
    ];
  });
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsg: Message = { role: 'user', content: textToSend };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMsg],
          workouts,
          history,
        }),
      });

      if (!response.ok) {
        throw new Error('Falha na resposta do servidor do Coach IA.');
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: data.content },
      ]);
    } catch (err: any) {
      console.error(err);
      
      // Smart Fallback offline/no-key answers for excellent user experience
      let fallbackAnswer = 'Não consegui conectar ao cérebro do Coach IA. Certifique-se de que sua chave GEMINI_API_KEY está configurada corretamente nos segredos do seu aplicativo no AI Studio.';
      
      const lowerText = textToSend.toLowerCase();
      if (lowerText.includes('analise') || lowerText.includes('ficha') || lowerText.includes('meu treino')) {
        const totalW = workouts.length;
        const activeW = workouts.find(w => w.isActive);
        fallbackAnswer = `**[Análise Offline do Coach]** 💪
Vejo que você tem **${totalW} fichas de treino** cadastradas.
O seu treino ativo no momento é o **"${activeW?.name || 'Nenhum'}"** com **${activeW?.exercises.length || 0} exercícios**.

**Sugestão de Distribuição de Volume:**
1. Atualmente você tem um bom equilíbrio de empurrar (peito/ombro) e puxar (costas/biceps).
2. Lembre-se de descansar pelo menos 60-90 segundos entre as séries para restaurar o estoque de ATP e manter a alta performance!
3. Se quiser uma análise hiper-detalhada com justificativas biomefisiológicas, configure a **GEMINI_API_KEY** nas configurações de Secrets do AI Studio!`;
      } else if (lowerText.includes('peito')) {
        fallbackAnswer = `**[Foco em Peitoral - Dica do Coach]** 🎯
No seu treino ativo, você possui exercícios como Supino Inclinado com Halteres ou Supino Reto.
- Para otimizar a hipertrofia do peito, certifique-se de retrair as escápulas (esmagar as costas contra o banco) para isolar o peitoral e tirar a tensão dos ombros.
- Faça de 10 a 20 séries semanais totais para o peito para excelente estímulo. Atualmente seu treino está muito bem estruturado!`;
      } else if (lowerText.includes('costas')) {
        fallbackAnswer = `**[Foco em Costas - Dica do Coach]** ✈️
Para focar em Costas e construir asas (largura e densidade):
- Utilize a Puxada Pulley focado em trazer o cotovelo em direção ao bolso, e não apenas puxando com o bíceps.
- Adicione Remada Curvada com Barra se desejar espessura média. Mantenha as escápulas ativas!`;
      } else if (lowerText.includes('hipertrofia')) {
        fallbackAnswer = `**[Hipertrofia de Elite - Pilares do Coach]** ⚡
Para sinalizar a máxima síntese proteica:
1. **Tensão Mecânica**: Progrida cargas e faça cada repetição valer a pena, chegando a 1-2 repetições antes da falha.
2. **Volume Adequado**: De 12 a 20 séries válidas por agrupamento muscular semanal.
3. **Superávit Calórico Limpo**: Coma um pouco mais do que gasta e consuma pelo menos 1.6g a 2.0g de proteína por kg de peso corporal.`;
      }

      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: fallbackAnswer },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickPrompts = [
    { text: 'Analise meu treino 🏋️', query: 'Analise meu treino cadastrado.' },
    { text: 'Estou treinando pouco peito? 🧐', query: 'Estou treinando pouco peito?' },
    { text: 'Quero focar em costas ✈️', query: 'Dicas e treino para focar mais em costas.' },
    { text: 'Dicas de hipertrofia ⚡', query: 'Quais são as melhores dicas para hipertrofia muscular?' },
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] max-h-screen px-4 py-2">
      {/* Bot Header */}
      <div className="flex items-center space-x-3 bg-[#1A1A1A] p-4 rounded-2xl border border-[#222] shadow-sm mb-4">
        <div className="p-2.5 bg-[#4F8CFF]/10 text-[#4F8CFF] rounded-xl border border-[#4F8CFF]/20">
          <Bot className="h-6 w-6 stroke-[2.5]" />
        </div>
        <div>
          <div className="flex items-center space-x-1.5">
            <h2 className="text-sm font-black text-white uppercase tracking-wider">Coach IA RepFlow</h2>
            <span className="text-[9px] font-bold bg-green-500/10 text-green-400 border border-green-500/20 px-1.5 py-0.5 rounded uppercase">
              Online
            </span>
          </div>
          <p className="text-[10px] text-gray-500 font-mono mt-0.5">GEMINI INTEL • PERSONAL COACH</p>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto bg-[#0D0D0D] rounded-2xl p-3 border border-[#161616] space-y-4 mb-4 custom-scrollbar">
        {messages.map((msg, index) => {
          const isAi = msg.role === 'assistant';
          return (
            <div
              key={index}
              className={`flex items-start space-x-3 max-w-[88%] ${isAi ? 'mr-auto' : 'ml-auto flex-row-reverse space-x-reverse'}`}
            >
              <div className={`p-2 rounded-xl text-xs flex-shrink-0 ${
                isAi 
                  ? 'bg-[#1C2638] text-[#4F8CFF] border border-[#4F8CFF]/20' 
                  : 'bg-[#262626] text-gray-400 border border-[#333]'
              }`}>
                {isAi ? <Bot className="h-4 w-4" /> : <User className="h-4 w-4" />}
              </div>

              <div className={`p-3.5 rounded-2xl text-sm leading-relaxed ${
                isAi
                  ? 'bg-[#1A1A1A] text-gray-100 border border-[#222]'
                  : 'bg-gradient-to-br from-[#4F8CFF] to-[#3B72D9] text-white font-medium'
              }`}>
                <div className="prose prose-invert prose-sm max-w-none">
                  {msg.content.split('\n').map((line, lIdx) => {
                    // Simple bullet/bold custom parser
                    let formattedLine = line;
                    
                    // Simple replacement for bold text markdown **text**
                    if (formattedLine.includes('**')) {
                      const regex = /\*\*(.*?)\*\*/g;
                      const parts = [];
                      let lastIndex = 0;
                      let match;
                      while ((match = regex.exec(formattedLine)) !== null) {
                        parts.push(formattedLine.substring(lastIndex, match.index));
                        parts.push(<strong key={match.index} className="text-white font-extrabold">{match[1]}</strong>);
                        lastIndex = regex.lastIndex;
                      }
                      parts.push(formattedLine.substring(lastIndex));
                      return <p key={lIdx} className="mb-1.5 last:mb-0">{parts}</p>;
                    }

                    // Render list bullet points
                    if (formattedLine.startsWith('- ') || formattedLine.startsWith('* ')) {
                      return (
                        <div key={lIdx} className="flex items-start space-x-1.5 pl-2 mb-1">
                          <span className="text-[#4F8CFF] mt-1.5 text-[8px]">•</span>
                          <span>{formattedLine.substring(2)}</span>
                        </div>
                      );
                    }

                    return <p key={lIdx} className="mb-1.5 last:mb-0">{formattedLine}</p>;
                  })}
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-start space-x-3 max-w-[80%] mr-auto">
            <div className="p-2 rounded-xl bg-[#1C2638] text-[#4F8CFF] border border-[#4F8CFF]/20 animate-pulse">
              <Bot className="h-4 w-4" />
            </div>
            <div className="bg-[#1A1A1A] text-gray-400 p-4 rounded-2xl border border-[#222] flex items-center space-x-2.5">
              <div className="flex space-x-1">
                <div className="w-2.5 h-2.5 bg-[#4F8CFF] rounded-full animate-bounce [animation-delay:-0.3s]" />
                <div className="w-2.5 h-2.5 bg-[#4F8CFF] rounded-full animate-bounce [animation-delay:-0.15s]" />
                <div className="w-2.5 h-2.5 bg-[#4F8CFF] rounded-full animate-bounce" />
              </div>
              <span className="text-xs font-mono tracking-wider animate-pulse">COACH PROCESSANDO...</span>
            </div>
          </div>
        )}

        {error && (
          <div className="bg-red-950/10 border border-red-900/30 p-3.5 rounded-xl flex items-center space-x-3 text-red-400">
            <AlertCircle className="h-5 w-5 flex-shrink-0" />
            <div className="text-xs">
              <span className="font-bold">Ocorreu um erro:</span> {error}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Helper */}
      {!isLoading && messages.length < 5 && (
        <div className="mb-4">
          <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest mb-2 px-1">Perguntas Frequentes</p>
          <div className="flex overflow-x-auto gap-2 pb-1.5 custom-scrollbar-horizontal">
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(qp.query)}
                className="flex-shrink-0 bg-[#1A1A1A] hover:bg-[#222] border border-[#222] hover:border-[#333] text-gray-300 text-xs py-2.5 px-3.5 rounded-xl font-medium transition-all active:scale-95"
              >
                {qp.text}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(input);
        }}
        className="flex items-center space-x-2 bg-[#1A1A1A] p-2 rounded-2xl border border-[#222] mb-12 shadow-inner"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Escreva sua pergunta para o Coach IA..."
          disabled={isLoading}
          className="flex-1 bg-transparent border-0 outline-none text-sm text-white placeholder-gray-600 px-3 py-2 disabled:opacity-50"
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className={`p-3 rounded-xl transition-all ${
            input.trim() && !isLoading
              ? 'bg-[#4F8CFF] text-white cursor-pointer active:scale-95'
              : 'bg-[#222] text-gray-600 cursor-not-allowed'
          }`}
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}
