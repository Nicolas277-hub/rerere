export interface Exercise {
  id: string;
  name: string;
  primaryMuscle: string;
  secondaryMuscle?: string;
  equipment?: string;
  difficulty?: 'Iniciante' | 'Intermediário' | 'Avançado';
  instructions?: string[];
  commonMistakes?: string[];
  tips?: string[];
  category?: string; // e.g. "Peito", "Costas", "Pernas", etc.
}

export interface WorkoutExercise {
  id: string; // unique instance ID in this routine
  exerciseId: string; // reference to the global exercise database ID
  name: string;
  primaryMuscle: string;
  secondaryMuscle?: string;
  setsCount: number;
  repsRange: string; // e.g., "6-8", "10", "12"
  restTime: number; // rest time in seconds, e.g. 90
  notes?: string;
  targetWeight?: number; // currently configured target weight in kg
}

export interface Workout {
  id: string;
  name: string; // e.g., "Treino A - Peito e Tríceps"
  isActive: boolean;
  exercises: WorkoutExercise[];
}

export interface SetLog {
  setNumber: number;
  weight: number;
  reps: number;
  completed: boolean;
}

export interface ExerciseLog {
  id: string;
  workoutId: string;
  exerciseId: string;
  exerciseName: string;
  date: string; // ISO string or YYYY-MM-DD
  sets: SetLog[];
  notes?: string;
}

export interface AppState {
  workouts: Workout[];
  activeWorkoutId: string | null;
  history: ExerciseLog[];
}
